"""Typed track-specific lab scenario variants."""

from __future__ import annotations

from .catalog import LAB_CATALOG
from .schemas import LabTrackVariant, TrackProfile
from .tracks import CANONICAL_TRACKS, get_track_profile, normalize_track_id


PILOT_LAB_IDS = (
    "v1_00_architects_portal",
    "v1_10_compression_paradox",
    "v1_11_hardware_roofline",
    "v1_12_benchmarking_trap",
    "v2_10_inference_economy",
    "v2_11_edge_thermodynamics",
)

ALL_LAB_IDS = tuple(metadata.lab_id for metadata in LAB_CATALOG.values())

_MODEL_REF_BY_TRACK = {
    "iphone": "Models.Vision.MobileNetV2",
    "oura_ring": "Models.Tiny.DS_CNN",
    "robotaxi": "Models.Vision.YOLOv8_Nano",
    "cloud_fleet": "Models.Language.BERT_Base",
}


def _variant(
    *,
    lab_id: str,
    track_id: str,
    scenario_id: str,
    stakeholder: str,
    workload_summary: str,
    objective: str,
    primary_metric: str,
    guardrail_metric: str,
    model_ref: str,
    defaults: dict[str, object],
    assumptions: dict[str, object],
) -> LabTrackVariant:
    profile = get_track_profile(track_id)
    return LabTrackVariant(
        lab_id=lab_id,
        track_id=profile.track_id,
        scenario_id=scenario_id,
        stakeholder=stakeholder,
        workload_summary=workload_summary,
        objective=objective,
        primary_metric=primary_metric,
        guardrail_metric=guardrail_metric,
        hardware_ref=profile.hardware_ref,
        system_ref=profile.system_ref,
        model_ref=model_ref,
        defaults=defaults,
        assumptions=assumptions,
    )


_HAND_AUTHORED_VARIANTS: tuple[LabTrackVariant, ...] = (
    # Lab 00: orientation and track identity.
    _variant(
        lab_id="v1_00_architects_portal",
        track_id="iphone",
        scenario_id="v1_00_iphone_track_identity",
        stakeholder="Mobile product engineer",
        workload_summary="Repeated on-device app inference used to introduce battery, thermal, privacy, and memory constraints.",
        objective="Choose iPhone as the persistent course track and predict the first recurring bottleneck.",
        primary_metric="thermal and battery headroom",
        guardrail_metric="interactive responsiveness",
        model_ref="Models.Vision.MobileNetV2",
        defaults={"initial_bottleneck": "thermal envelope", "assignment_mode": "student choice"},
        assumptions={"report_artifact": "orientation memo", "solver_required": False},
    ),
    _variant(
        lab_id="v1_00_architects_portal",
        track_id="oura_ring",
        scenario_id="v1_00_oura_track_identity",
        stakeholder="Wearable firmware engineer",
        workload_summary="Always-on wearable sensing used to introduce SRAM, flash, OTA, and battery constraints.",
        objective="Choose Oura Ring as the persistent course track and predict the first recurring bottleneck.",
        primary_metric="SRAM and flash fit",
        guardrail_metric="battery life",
        model_ref="Models.Tiny.DS_CNN",
        defaults={"initial_bottleneck": "SRAM", "assignment_mode": "student choice"},
        assumptions={"report_artifact": "orientation memo", "solver_required": False},
    ),
    _variant(
        lab_id="v1_00_architects_portal",
        track_id="robotaxi",
        scenario_id="v1_00_robotaxi_track_identity",
        stakeholder="Autonomous vehicle platform engineer",
        workload_summary="Vehicle-local perception loop used to introduce p99 latency, reliability, power, and safety guardrails.",
        objective="Choose RoboTaxi as the persistent course track and predict the first recurring bottleneck.",
        primary_metric="p99 latency",
        guardrail_metric="rare-event recall",
        model_ref="Models.Vision.YOLOv8_Nano",
        defaults={"initial_bottleneck": "tail latency", "assignment_mode": "student choice"},
        assumptions={"report_artifact": "orientation memo", "solver_required": False},
    ),
    _variant(
        lab_id="v1_00_architects_portal",
        track_id="cloud_fleet",
        scenario_id="v1_00_cloud_fleet_track_identity",
        stakeholder="Fleet service owner",
        workload_summary="Production inference fleet used to introduce throughput, cost, utilization, SLA, and carbon constraints.",
        objective="Choose Cloud Fleet as the persistent course track and predict the first recurring bottleneck.",
        primary_metric="throughput",
        guardrail_metric="SLA",
        model_ref="Models.Language.BERT_Base",
        defaults={"initial_bottleneck": "utilization", "assignment_mode": "student choice"},
        assumptions={"report_artifact": "orientation memo", "solver_required": False},
    ),

    # V1-10: Compression Paradox pilot.
    _variant(
        lab_id="v1_10_compression_paradox",
        track_id="iphone",
        scenario_id="v1_10_iphone_compression",
        stakeholder="Mobile product lead",
        workload_summary="Repeated mobile vision inference with sustained UX and supported-accelerator constraints.",
        objective="Choose a compression recipe that reduces battery/thermal pressure without CPU or GPU fallback.",
        primary_metric="battery or thermal headroom",
        guardrail_metric="quality and on-device p99 latency",
        model_ref="Models.Vision.MobileNetV2",
        defaults={
            "candidate_methods": ("int8_quantization", "structured_pruning", "distillation"),
            "bit_widths": (16, 8, 6, 4),
            "size_limit_ref": "memory.capacity",
            "max_accuracy_drop": 0.01,
            "min_speedup": 1.05,
            "require_hardware_support": True,
            "validation_tests": ("sustained-device benchmark", "NPU fast-path verification", "thermal soak test"),
        },
        assumptions={"unsupported_kernel_policy": "marks infeasible", "report_artifact": "compression deployment recipe"},
    ),
    _variant(
        lab_id="v1_10_compression_paradox",
        track_id="oura_ring",
        scenario_id="v1_10_oura_compression",
        stakeholder="Wearable firmware lead",
        workload_summary="Low-rate biosignal classifier with strict runtime memory and OTA payload constraints.",
        objective="Choose a compression recipe that fits model, runtime, and OTA package while preserving battery and signal guardrails.",
        primary_metric="flash/SRAM fit and OTA payload size",
        guardrail_metric="battery life and signal quality",
        model_ref="Models.Tiny.DS_CNN",
        defaults={
            "candidate_methods": ("int8_quantization", "structured_pruning", "distillation"),
            "bit_widths": (8, 6, 4, 3, 2),
            "size_limit_ref": "memory.flash_capacity",
            "max_accuracy_drop": 0.02,
            "min_speedup": 1.0,
            "require_hardware_support": True,
            "validation_tests": ("flash/SRAM budget check", "OTA payload test", "battery-life regression"),
        },
        assumptions={"runtime_memory_included": True, "report_artifact": "compression deployment recipe"},
    ),
    _variant(
        lab_id="v1_10_compression_paradox",
        track_id="robotaxi",
        scenario_id="v1_10_robotaxi_compression",
        stakeholder="Safety/perception lead",
        workload_summary="Vehicle-local perception model under bursty sensor workload and tail-latency safety constraints.",
        objective="Choose a compression recipe that lowers p99 latency without reducing rare-hazard recall.",
        primary_metric="p99 or p999 latency",
        guardrail_metric="rare-event recall",
        model_ref="Models.Vision.YOLOv8_Nano",
        defaults={
            "candidate_methods": ("int8_quantization", "structured_pruning", "distillation"),
            "bit_widths": (16, 8, 6, 4),
            "size_limit_ref": "memory.capacity",
            "max_accuracy_drop": 0.005,
            "min_speedup": 1.05,
            "require_hardware_support": True,
            "validation_tests": ("rare-event replay suite", "p99 burst-latency test", "safety recall regression"),
        },
        assumptions={"rare_event_validation_required": True, "report_artifact": "compression deployment recipe"},
    ),
    _variant(
        lab_id="v1_10_compression_paradox",
        track_id="cloud_fleet",
        scenario_id="v1_10_cloud_fleet_compression",
        stakeholder="Infrastructure lead",
        workload_summary="High-volume inference service where compression changes cost/request, throughput, quality, and SLA.",
        objective="Choose a compression recipe that improves cost/request or throughput without quality or SLA regression.",
        primary_metric="cost/request or throughput",
        guardrail_metric="quality and SLA",
        model_ref="Models.Language.BERT_Base",
        defaults={
            "candidate_methods": ("int8_quantization", "structured_pruning", "distillation"),
            "bit_widths": (16, 8, 6, 4),
            "size_limit_ref": "memory.capacity",
            "max_accuracy_drop": 0.01,
            "min_speedup": 1.05,
            "require_hardware_support": True,
            "validation_tests": ("load/SLA test", "quality regression suite", "cost/request canary"),
        },
        assumptions={"fleet_profile": "Systems.Clusters.Lab_64_H100", "report_artifact": "compression deployment recipe"},
    ),

    # V1-11: Hardware Roofline pilot.
    _variant(
        lab_id="v1_11_hardware_roofline",
        track_id="iphone",
        scenario_id="v1_11_iphone_roofline",
        stakeholder="Mobile accelerator engineer",
        workload_summary="Mobile vision kernels that must stay on the Neural Engine fast path without excess DRAM traffic.",
        objective="Diagnose whether the selected mobile workload is compute-bound, bandwidth-bound, or unsupported-path limited.",
        primary_metric="on-device attainable GFLOP/s",
        guardrail_metric="thermal and interactive latency headroom",
        model_ref="Models.Vision.MobileNetV2",
        defaults={
            "matrix_dim": 512,
            "precision": "fp16",
            "compare_tracks": ("iphone", "cloud_fleet"),
            "move_the_point": ("fusion", "batching", "precision"),
            "validation_tests": ("supported-op fast-path check", "thermal soak", "interactive latency test"),
        },
        assumptions={"report_artifact": "hardware acceleration diagnosis", "accelerator_path": "Neural Engine"},
    ),
    _variant(
        lab_id="v1_11_hardware_roofline",
        track_id="oura_ring",
        scenario_id="v1_11_oura_roofline",
        stakeholder="Wearable firmware engineer",
        workload_summary="Tiny biosignal kernels that must fit the MCU/SRAM envelope before peak ops matter.",
        objective="Diagnose the tiny roofline and decide whether tiling, precision, or model reduction is the first lever.",
        primary_metric="SRAM-resident attainable ops",
        guardrail_metric="battery and firmware memory fit",
        model_ref="Models.Tiny.DS_CNN",
        defaults={
            "matrix_dim": 128,
            "precision": "int8",
            "compare_tracks": ("oura_ring", "iphone"),
            "move_the_point": ("tiling", "int8", "model_reduction"),
            "validation_tests": ("SRAM tile check", "flash image check", "battery regression"),
        },
        assumptions={"report_artifact": "hardware acceleration diagnosis", "accelerator_path": "MCU/tiny int8 path"},
    ),
    _variant(
        lab_id="v1_11_hardware_roofline",
        track_id="robotaxi",
        scenario_id="v1_11_robotaxi_roofline",
        stakeholder="Autonomous vehicle platform engineer",
        workload_summary="Vehicle-local perception kernels under hard p99 latency and power-envelope constraints.",
        objective="Diagnose roofline headroom for the vehicle-local accelerator and name the residual safety margin.",
        primary_metric="p99 latency headroom",
        guardrail_metric="safety margin and power envelope",
        model_ref="Models.Vision.YOLOv8_Nano",
        defaults={
            "matrix_dim": 1024,
            "precision": "int8",
            "compare_tracks": ("robotaxi", "cloud_fleet"),
            "move_the_point": ("sensor_pipeline_overlap", "int8", "fusion"),
            "validation_tests": ("p99 replay", "sensor burst test", "power envelope check"),
        },
        assumptions={"report_artifact": "hardware acceleration diagnosis", "accelerator_path": "vehicle-local accelerator"},
    ),
    _variant(
        lab_id="v1_11_hardware_roofline",
        track_id="cloud_fleet",
        scenario_id="v1_11_cloud_fleet_roofline",
        stakeholder="GPU performance engineer",
        workload_summary="High-throughput service kernels where HBM bandwidth, tensor-core utilization, and batching determine cost.",
        objective="Diagnose GPU roofline utilization and decide which transform improves cost/request without SLA regression.",
        primary_metric="MFU and cost/request",
        guardrail_metric="SLA and quality",
        model_ref="Models.Language.BERT_Base",
        defaults={
            "matrix_dim": 1024,
            "precision": "fp16",
            "compare_tracks": ("cloud_fleet", "robotaxi"),
            "move_the_point": ("batching", "fusion", "tensor_core_precision"),
            "validation_tests": ("load test", "kernel profiler", "SLA canary"),
        },
        assumptions={"fleet_profile": "Systems.Clusters.Lab_64_H100", "report_artifact": "hardware acceleration diagnosis", "accelerator_path": "H100 tensor cores"},
    ),

    # V1-12: Benchmarking Trap pilot.
    _variant(
        lab_id="v1_12_benchmarking_trap",
        track_id="iphone",
        scenario_id="v1_12_iphone_sustained_benchmark",
        stakeholder="Mobile release manager",
        workload_summary="A short on-device benchmark reports excellent latency, but the production app must survive sustained thermal and battery pressure.",
        objective="Design a benchmark protocol that proves sustained on-device performance, not only cold-start peak latency.",
        primary_metric="sustained p99 latency and thermal headroom",
        guardrail_metric="battery drain and responsiveness",
        model_ref="Models.Vision.MobileNetV2",
        defaults={
            "benchmark_claim": "30 ms cold-run latency",
            "hidden_failure_metric": "sustained thermal throttling and battery drain",
            "component_label": "Neural Engine inference",
            "metric_unit": "FPS",
            "burst_value": 60.0,
            "sustained_threshold": 0.75,
            "component_speedup": 10.0,
            "serial_pct": 35.0,
            "duration_s": 600,
            "ambient_c": 35.0,
            "cooling": "fanless",
            "accuracy_min_pct": 90.0,
            "p99_max_ms": 80.0,
            "power_max_w": 4.0,
            "throughput_min": 30.0,
            "tail_base_ms": 35.0,
            "tail_sigma": 0.7,
            "tail_slo_ms": 100.0,
            "validation_tests": ("10-minute sustained run", "battery drain replay", "thermal soak", "p99 UI latency"),
        },
        assumptions={"report_artifact": "benchmark protocol memo", "protocol_scope": "sustained on-device run"},
    ),
    _variant(
        lab_id="v1_12_benchmarking_trap",
        track_id="oura_ring",
        scenario_id="v1_12_oura_duty_cycle_benchmark",
        stakeholder="Wearable validation lead",
        workload_summary="A single-inference benchmark looks tiny, but always-on operation must preserve duty cycle, SRAM fit, OTA size, and days of battery life.",
        objective="Design a benchmark protocol that tests duty-cycle energy and memory fit rather than isolated inference latency.",
        primary_metric="mWh/day and SRAM fit",
        guardrail_metric="battery life and OTA payload",
        model_ref="Models.Tiny.DS_CNN",
        defaults={
            "benchmark_claim": "sub-millisecond keyword-spotting inference",
            "hidden_failure_metric": "duty-cycle energy, SRAM fit, and OTA payload",
            "component_label": "tiny classifier inference",
            "metric_unit": "inferences/s",
            "burst_value": 20.0,
            "sustained_threshold": 0.85,
            "component_speedup": 4.0,
            "serial_pct": 55.0,
            "duration_s": 900,
            "ambient_c": 32.0,
            "cooling": "fanless",
            "accuracy_min_pct": 88.0,
            "p99_max_ms": 250.0,
            "power_max_w": 0.02,
            "throughput_min": 0.02,
            "tail_base_ms": 80.0,
            "tail_sigma": 0.6,
            "tail_slo_ms": 300.0,
            "validation_tests": ("24-hour duty-cycle replay", "SRAM/flash audit", "OTA payload check", "battery regression"),
        },
        assumptions={"report_artifact": "benchmark protocol memo", "protocol_scope": "always-on duty cycle"},
    ),
    _variant(
        lab_id="v1_12_benchmarking_trap",
        track_id="robotaxi",
        scenario_id="v1_12_robotaxi_rare_event_benchmark",
        stakeholder="Autonomous vehicle safety validation lead",
        workload_summary="Average perception latency looks safe, but sensor bursts and rare-event replay expose p99/p999 safety failures.",
        objective="Design a benchmark protocol that uses p99/p999 latency and rare-event recall, not average frame latency.",
        primary_metric="p99/p999 latency under sensor bursts",
        guardrail_metric="rare-event recall and safety margin",
        model_ref="Models.Vision.YOLOv8_Nano",
        defaults={
            "benchmark_claim": "30 FPS average perception pipeline",
            "hidden_failure_metric": "p99/p999 burst latency and rare-event recall",
            "component_label": "vehicle-local perception",
            "metric_unit": "FPS",
            "burst_value": 30.0,
            "sustained_threshold": 0.90,
            "component_speedup": 6.0,
            "serial_pct": 40.0,
            "duration_s": 600,
            "ambient_c": 40.0,
            "cooling": "passive",
            "accuracy_min_pct": 92.0,
            "p99_max_ms": 50.0,
            "power_max_w": 60.0,
            "throughput_min": 30.0,
            "tail_base_ms": 22.0,
            "tail_sigma": 0.85,
            "tail_slo_ms": 50.0,
            "validation_tests": ("sensor burst replay", "p99/p999 latency", "rare-event replay", "power envelope"),
        },
        assumptions={"report_artifact": "benchmark protocol memo", "protocol_scope": "safety replay"},
    ),
    _variant(
        lab_id="v1_12_benchmarking_trap",
        track_id="cloud_fleet",
        scenario_id="v1_12_cloud_load_benchmark",
        stakeholder="Cloud SRE lead",
        workload_summary="Peak throughput looks strong, but production load exposes p99 latency, utilization, cost/request, and quality regressions.",
        objective="Design a benchmark protocol that measures load, tail latency, cost/request, and quality at production-like demand.",
        primary_metric="SLA-compliant throughput and cost/request",
        guardrail_metric="p99 latency and quality",
        model_ref="Models.Language.BERT_Base",
        defaults={
            "benchmark_claim": "peak throughput at batch 64",
            "hidden_failure_metric": "p99 latency and cost/request under load",
            "component_label": "accelerator inference",
            "metric_unit": "QPS",
            "burst_value": 1200.0,
            "sustained_threshold": 0.80,
            "component_speedup": 10.0,
            "serial_pct": 45.0,
            "duration_s": 600,
            "ambient_c": 25.0,
            "cooling": "active",
            "accuracy_min_pct": 90.0,
            "p99_max_ms": 100.0,
            "power_max_w": 700.0,
            "throughput_min": 500.0,
            "tail_base_ms": 50.0,
            "tail_sigma": 0.8,
            "tail_slo_ms": 200.0,
            "validation_tests": ("load test", "p99 latency", "cost/request canary", "quality regression"),
        },
        assumptions={"report_artifact": "benchmark protocol memo", "protocol_scope": "production-like load"},
    ),

    # V2-10: Inference Economy pilot.
    _variant(
        lab_id="v2_10_inference_economy",
        track_id="iphone",
        scenario_id="v2_10_iphone_local_inference",
        stakeholder="Mobile product owner",
        workload_summary="On-device vision inference where the recurring cost is battery, heat, and responsiveness rather than cloud spend.",
        objective="Decide how much inference stays on-device and how batching/offload changes battery and latency.",
        primary_metric="mWh per day of local inference",
        guardrail_metric="interactive p99 latency and thermal headroom",
        model_ref="Models.Vision.MobileNetV2",
        defaults={
            "setup_cost": 15_000.0,
            "cost_per_event": 0.02,
            "cost_unit": "mWh",
            "cost_label": "battery energy",
            "demand_qps": 2,
            "horizon_weeks": 8,
            "context_tokens": 2048,
            "state_kind": "activation/cache buffers",
            "state_mb_per_request": 64,
            "precision_bytes": 2.0,
            "slo_ms": 50,
            "qps_per_slot": 8.0,
            "devices_per_replica": 1,
            "batching_fill_factor": 0.80,
            "validation_tests": ("thermal soak", "interactive latency test", "battery drain replay"),
        },
        assumptions={"report_artifact": "inference serving plan", "serving_policy": "local with selective offload"},
    ),
    _variant(
        lab_id="v2_10_inference_economy",
        track_id="oura_ring",
        scenario_id="v2_10_oura_duty_cycle",
        stakeholder="Wearable firmware lead",
        workload_summary="Always-on sensing where inference economy is dominated by duty cycle, SRAM fit, and days of battery life.",
        objective="Choose a local inference schedule and handoff policy that preserves ring battery and memory fit.",
        primary_metric="mWh per day and duty-cycle budget",
        guardrail_metric="SRAM/flash fit and battery life",
        model_ref="Models.Tiny.DS_CNN",
        defaults={
            "setup_cost": 55.0,
            "cost_per_event": 0.0004,
            "cost_unit": "mWh",
            "cost_label": "ring battery energy",
            "demand_qps": 0.02,
            "horizon_weeks": 12,
            "context_tokens": 256,
            "state_kind": "sensor window buffers",
            "state_mb_per_request": 0.06,
            "precision_bytes": 1.0,
            "slo_ms": 250,
            "qps_per_slot": 0.2,
            "devices_per_replica": 1,
            "batching_fill_factor": 0.65,
            "validation_tests": ("SRAM budget check", "duty-cycle replay", "battery regression"),
        },
        assumptions={"report_artifact": "inference serving plan", "serving_policy": "ring-local with phone handoff"},
    ),
    _variant(
        lab_id="v2_10_inference_economy",
        track_id="robotaxi",
        scenario_id="v2_10_robotaxi_safety_serving",
        stakeholder="Autonomous fleet operations lead",
        workload_summary="Vehicle-local perception serving where recurring cost is power draw, deterministic p99 latency, and maintenance exposure.",
        objective="Keep safety-critical inference local while sizing state, batching, and replica headroom for sensor bursts.",
        primary_metric="Wh per vehicle-hour and p99 latency",
        guardrail_metric="safety margin under bursty sensor load",
        model_ref="Models.Vision.YOLOv8_Nano",
        defaults={
            "setup_cost": 6_000.0,
            "cost_per_event": 0.0002,
            "cost_unit": "Wh",
            "cost_label": "vehicle compute energy",
            "demand_qps": 30,
            "horizon_weeks": 4,
            "context_tokens": 4096,
            "state_kind": "sensor-frame state buffers",
            "state_mb_per_request": 768,
            "precision_bytes": 1.0,
            "slo_ms": 30,
            "qps_per_slot": 30.0,
            "devices_per_replica": 1,
            "batching_fill_factor": 0.75,
            "validation_tests": ("p99 replay", "sensor burst replay", "power envelope check"),
        },
        assumptions={"report_artifact": "inference serving plan", "serving_policy": "vehicle-local safety path"},
    ),
    _variant(
        lab_id="v2_10_inference_economy",
        track_id="cloud_fleet",
        scenario_id="v2_10_cloud_kv_fleet",
        stakeholder="Inference platform owner",
        workload_summary="Production LLM service where GPU-hours, KV cache memory, continuous batching, and replicas determine cost/request.",
        objective="Size an inference fleet that meets demand and p99 SLO at minimum daily cost.",
        primary_metric="cost/request and daily fleet cost",
        guardrail_metric="SLA and quality",
        model_ref="Models.Language.Llama2_70B",
        defaults={
            "setup_cost": 2_000_000.0,
            "cost_per_event": 0.01,
            "cost_unit": "USD",
            "cost_label": "serving spend",
            "demand_qps": 100,
            "horizon_weeks": 26,
            "context_tokens": 131_072,
            "state_kind": "KV cache",
            "precision_bytes": 2.0,
            "slo_ms": 200,
            "qps_per_slot": 1.5,
            "hardware_unit_cost_per_hour": 3.0,
            "devices_per_replica": 8,
            "batching_fill_factor": 0.85,
            "validation_tests": ("load test", "KV cache memory audit", "SLA canary", "cost/request canary"),
        },
        assumptions={"fleet_profile": "Systems.Clusters.Lab_64_H100", "report_artifact": "inference serving plan", "serving_policy": "continuous-batched GPU fleet"},
    ),

    # V2-11: Edge Thermodynamics pilot.
    _variant(
        lab_id="v2_11_edge_thermodynamics",
        track_id="iphone",
        scenario_id="v2_11_iphone_edge_placement",
        stakeholder="Mobile privacy engineer",
        workload_summary="Personalized on-device inference with optional phone-edge or cloud fallback.",
        objective="Choose what remains on-device and what can move off-device under latency, privacy, and battery constraints.",
        primary_metric="on-device latency and battery cost",
        guardrail_metric="privacy requirement",
        model_ref="Models.Vision.MobileNetV2",
        defaults={"placements": ("local", "phone_edge", "cloud", "hybrid"), "adaptation_options": ("local", "federated", "centralized")},
        assumptions={"privacy_sensitive": True, "report_artifact": "edge architecture memo"},
    ),
    _variant(
        lab_id="v2_11_edge_thermodynamics",
        track_id="oura_ring",
        scenario_id="v2_11_oura_edge_placement",
        stakeholder="Wearable systems engineer",
        workload_summary="Ring-local sensing with phone-assisted or cloud-assisted heavier computation.",
        objective="Choose a tiny local model plus handoff policy that preserves energy, memory, and privacy.",
        primary_metric="energy per inference",
        guardrail_metric="SRAM/flash fit",
        model_ref="Models.Tiny.AnomalyDetector",
        defaults={"placements": ("ring_only", "ring_phone", "ring_cloud", "hybrid"), "adaptation_options": ("calibration", "phone_mediated", "centralized")},
        assumptions={"phone_handoff_available": True, "report_artifact": "edge architecture memo"},
    ),
    _variant(
        lab_id="v2_11_edge_thermodynamics",
        track_id="robotaxi",
        scenario_id="v2_11_robotaxi_edge_placement",
        stakeholder="Autonomous fleet safety lead",
        workload_summary="Safety-critical vehicle perception with roadside/depot/cloud paths for non-critical learning loops.",
        objective="Keep the safety path vehicle-local while choosing how fleet learning and updates use edge or cloud.",
        primary_metric="vehicle-local p99 latency",
        guardrail_metric="safety-critical privacy and reliability",
        model_ref="Models.Vision.YOLOv8_Nano",
        defaults={"placements": ("vehicle_local", "roadside_edge", "depot_edge", "cloud"), "adaptation_options": ("fleet_learning", "centralized_retrain", "federated")},
        assumptions={"safety_path_must_be_local": True, "report_artifact": "edge architecture memo"},
    ),
    _variant(
        lab_id="v2_11_edge_thermodynamics",
        track_id="cloud_fleet",
        scenario_id="v2_11_cloud_fleet_edge_placement",
        stakeholder="Cloud service owner",
        workload_summary="Centralized service that may use edge caching, offload, or feedback loops to improve latency and cost.",
        objective="Choose when central serving is enough and when edge placement improves latency, cost, or feedback quality.",
        primary_metric="p99 latency and cost/request",
        guardrail_metric="SLA and quality",
        model_ref="Models.Language.BERT_Base",
        defaults={"placements": ("centralized", "edge_cache", "edge_offload", "hybrid"), "adaptation_options": ("centralized_retrain", "edge_feedback", "federated")},
        assumptions={"central_service_baseline": True, "report_artifact": "edge architecture memo"},
    ),
)


def _baseline_variant(lab_id: str, title: str, profile: TrackProfile) -> LabTrackVariant:
    """Create a conservative track variant for labs not yet hand-authored."""
    return LabTrackVariant(
        lab_id=lab_id,
        track_id=profile.track_id,
        scenario_id=f"{lab_id}_{profile.track_id}_baseline",
        stakeholder=profile.stakeholder,
        workload_summary=(
            f"{title} realized through the {profile.label} track. "
            f"{profile.narrative}"
        ),
        objective=(
            f"Apply the {title} lab decisions to {profile.label} and defend "
            "the track-specific trade-off using local evidence."
        ),
        primary_metric=profile.primary_metrics[0],
        guardrail_metric=profile.guardrail_metrics[0],
        hardware_ref=profile.hardware_ref,
        system_ref=profile.system_ref,
        model_ref=_MODEL_REF_BY_TRACK[profile.track_id],
        defaults={
            "assignment_mode": "track-aware baseline",
            "implementation_status": "baseline_variant_pending_notebook_migration",
            "dominant_constraints": profile.dominant_constraints,
            "primary_metrics": profile.primary_metrics,
            "guardrail_metrics": profile.guardrail_metrics,
        },
        assumptions={
            "report_artifact": f"{title} engineering memo",
            "solver_required": False,
            "source_policy": profile.source_policy,
            "fallback_variant": True,
        },
    )


def _baseline_variants() -> tuple[LabTrackVariant, ...]:
    hand_authored_lab_ids = {variant.lab_id for variant in _HAND_AUTHORED_VARIANTS}
    variants = []
    for metadata in LAB_CATALOG.values():
        if metadata.lab_id in hand_authored_lab_ids:
            continue
        for profile in CANONICAL_TRACKS:
            variants.append(_baseline_variant(metadata.lab_id, metadata.title, profile))
    return tuple(variants)


LAB_TRACK_VARIANTS: tuple[LabTrackVariant, ...] = _HAND_AUTHORED_VARIANTS + _baseline_variants()


_VARIANT_MAP: dict[tuple[str, str], LabTrackVariant] = {
    (variant.lab_id, variant.track_id): variant for variant in LAB_TRACK_VARIANTS
}


def list_lab_variants(lab_id: str) -> tuple[LabTrackVariant, ...]:
    """Return all track variants for a lab ID."""
    return tuple(variant for variant in LAB_TRACK_VARIANTS if variant.lab_id == lab_id)


def get_lab_track_variant(lab_id: str, track_id: str | None) -> LabTrackVariant:
    """Return the variant for a lab and canonical or legacy track ID."""
    normalized = normalize_track_id(track_id)
    try:
        return _VARIANT_MAP[(lab_id, normalized)]
    except KeyError as exc:
        raise KeyError(f"No variant for lab_id={lab_id!r}, track_id={track_id!r}") from exc


def variant_coverage() -> dict[str, tuple[str, ...]]:
    """Return available track IDs by lab ID for tests and dashboards."""
    return {
        lab_id: tuple(variant.track_id for variant in list_lab_variants(lab_id))
        for lab_id in ALL_LAB_IDS
    }


def canonical_track_ids() -> tuple[str, ...]:
    """Return canonical track IDs in display order."""
    return tuple(profile.track_id for profile in CANONICAL_TRACKS)


__all__ = [
    "LAB_TRACK_VARIANTS",
    "ALL_LAB_IDS",
    "PILOT_LAB_IDS",
    "canonical_track_ids",
    "get_lab_track_variant",
    "list_lab_variants",
    "variant_coverage",
]
