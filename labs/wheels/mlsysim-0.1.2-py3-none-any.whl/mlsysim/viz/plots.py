# viz/plots.py
# Simulator-aware plotters for generated MLSysIM figures. Every plotter draws
# through the shared style in viz/style.py.

try:
    import numpy as np
except ImportError:
    np = None

from .style import (
    BODY_FIGSIZE,
    COLORS,
    MIN_FONT_PT,
    WEB_FIG_DPI,
    bar_compare,
    finalize_web_figure as _finalize_web_figure,
    plt,
    set_book_style,
    setup_plot,
)

__all__ = [
    "BODY_FIGSIZE",
    "COLORS",
    "MIN_FONT_PT",
    "WEB_FIG_DPI",
    "bar_compare",
    "plt",
    "set_book_style",
    "setup_plot",
    "plot_roofline",
    "plot_distributed_roofline",
    "plot_evaluation_scorecard",
]


def plot_roofline(hardware_node, workloads=None, title=None):
    """
    Plots a publication-quality Roofline Model for a given HardwareNode.

    Features:
    - Ridge point annotated with numeric value
    - Memory-bound and compute-bound regions shaded and labeled
    - Memory bandwidth ceiling (diagonal) and compute ceiling (flat)
    - Workloads plotted with bottleneck classification
    """
    # 1. PARAMETERS
    peak_flops = hardware_node.compute.peak_flops.to("TFLOPs/s").magnitude
    peak_bw = hardware_node.memory.bandwidth.to("GB/s").magnitude
    ridge_point = peak_flops / (peak_bw / 1000)  # FLOP/Byte

    # 2. AXIS RANGE
    x_min, x_max = 0.1, 10000
    x = np.logspace(np.log10(x_min), np.log10(x_max), 500)

    # 3. ROOFLINE CURVES
    y_mem = peak_bw * x / 1000  # BW * AI, converted to TFLOP/s
    y_compute = np.full_like(x, peak_flops)
    y_roof = np.minimum(y_mem, y_compute)

    # 4. PLOT
    fig, ax, colors, _ = setup_plot(figsize=(BODY_FIGSIZE[0], 4.6))

    # Shaded regions
    mem_mask = x <= ridge_point
    comp_mask = x >= ridge_point
    ax.fill_between(
        x[mem_mask],
        y_roof[mem_mask] * 0.001,
        y_roof[mem_mask],
        color=colors["BlueL"],
        alpha=0.5,
        label="Memory-bound region",
    )
    ax.fill_between(
        x[comp_mask],
        y_roof[comp_mask] * 0.001,
        y_roof[comp_mask],
        color=colors["OrangeL"],
        alpha=0.5,
        label="Compute-bound region",
    )

    # Roofline line
    ax.loglog(
        x[mem_mask],
        y_roof[mem_mask],
        color=colors["BlueLine"],
        linewidth=2.5,
        zorder=5,
    )
    ax.loglog(
        x[comp_mask],
        y_roof[comp_mask],
        color=colors["OrangeLine"],
        linewidth=2.5,
        zorder=5,
    )

    # Memory bandwidth ceiling label (on the slope)
    slope_x = ridge_point * 0.08
    slope_y = peak_bw * slope_x / 1000
    ax.text(
        slope_x,
        slope_y * 1.6,
        f"BW ceiling: {peak_bw:.0f} GB/s",
        color=colors["BlueLine"],
        fontsize=MIN_FONT_PT,
        fontweight="bold",
        rotation=38,
        ha="center",
        va="bottom",
    )

    # Compute ceiling label (on the flat)
    ax.text(
        x_max * 0.8,
        peak_flops * 1.12,
        f"Compute ceiling: {peak_flops:.0f} TFLOP/s",
        color=colors["OrangeLine"],
        fontsize=MIN_FONT_PT,
        fontweight="bold",
        ha="right",
        va="bottom",
    )

    # Ridge point
    ax.plot(
        ridge_point,
        peak_flops,
        "D",
        color=colors["crimson"],
        markersize=9,
        zorder=10,
    )
    ax.annotate(
        f"Ridge Point\n{ridge_point:.1f} FLOP/Byte",
        xy=(ridge_point, peak_flops),
        xytext=(ridge_point * 2.6, peak_flops * 0.26),
        fontsize=MIN_FONT_PT,
        fontweight="bold",
        color=colors["crimson"],
        ha="center",
        arrowprops=dict(
            arrowstyle="->",
            color=colors["crimson"],
            lw=1.2,
        ),
    )

    # Vertical dashed line at ridge point
    ax.axvline(
        ridge_point,
        color=colors["crimson"],
        linestyle=":",
        linewidth=0.8,
        alpha=0.5,
    )

    # Region labels
    ax.text(
        (x_min * ridge_point) ** 0.5,
        peak_flops * 0.02,
        "MEMORY\nBOUND",
        color=colors["BlueLine"],
        fontsize=11,
        fontweight="bold",
        alpha=0.25,
        ha="left",
        va="center",
    )
    ax.text(
        (ridge_point * x_max) ** 0.5,
        peak_flops * 0.02,
        "COMPUTE\nBOUND",
        color=colors["OrangeLine"],
        fontsize=11,
        fontweight="bold",
        alpha=0.25,
        ha="center",
        va="center",
    )

    # Plot workloads
    if workloads:
        from ..engine.solvers import SingleNodeModel

        workload_colors = [
            colors["primary"],
            colors["GreenLine"],
            colors["VioletLine"],
            colors["BrownLine"],
        ]
        for i, model in enumerate(workloads):
            profile = SingleNodeModel().solve(model, hardware_node, efficiency=1.0)
            ai = profile.arithmetic_intensity.magnitude
            perf = min(peak_bw * ai / 1000, peak_flops)
            c = workload_colors[i % len(workload_colors)]
            bound = "memory" if ai < ridge_point else "compute"
            ax.plot(ai, perf, "o", color=c, markersize=9, zorder=10)
            ax.annotate(
                f"{model.name}\n({bound}-bound)",
                xy=(ai, perf),
                xytext=(ai * 0.3, perf * 0.4),
                fontsize=MIN_FONT_PT,
                fontweight="bold",
                color=c,
                ha="center",
                arrowprops=dict(arrowstyle="->", color=c, lw=1),
            )

    ax.set_xlabel("Arithmetic Intensity (FLOP/Byte)")
    ax.set_ylabel("Performance (TFLOP/s)")
    # The document caption owns the figure title; pass `title` only for
    # standalone use outside the book.
    if title:
        ax.set_title(title)
    ax.set_xlim(x_min, x_max)
    ax.set_ylim(peak_flops * 0.001, peak_flops * 2)
    ax.legend(loc="lower right", fontsize=MIN_FONT_PT, framealpha=0.9)
    return _finalize_web_figure(fig), ax

def plot_distributed_roofline(fleet_system, workloads=None):
    """
    Plots a Distributed (Network) Roofline Model for a given fleet.
    Maps Performance (TFLOP/s) against Communication Intensity (FLOP/Byte).
    
    Timeless Principle: The Network Wall is hit when gradient/activation
    synchronization exceeds the fleet's bisection bandwidth.
    """
    # 1. PARAMETERS (Fleet Specs)
    peak_flops = fleet_system.node.accelerator.compute.peak_flops.to("TFLOPs/s").magnitude * fleet_system.count
    # Bisection Bandwidth (total network capacity for All-Reduce)
    peak_network_bw = fleet_system.fabric.bandwidth.to("GB/s").magnitude
    ridge_point = peak_flops / (peak_network_bw / 1000) # FLOP/Byte

    # 2. AXIS RANGE
    x_min, x_max = 0.1, 10000
    x = np.logspace(np.log10(x_min), np.log10(x_max), 500)

    # 3. ROOFLINE CURVES
    y_net = peak_network_bw * x / 1000  # Network BW * CI, converted to TFLOP/s
    y_compute = np.full_like(x, peak_flops)
    y_roof = np.minimum(y_net, y_compute)

    # 4. PLOT
    fig, ax, colors, _ = setup_plot(figsize=(BODY_FIGSIZE[0], 4.6))

    # Shaded regions
    net_mask = x <= ridge_point
    comp_mask = x >= ridge_point
    ax.fill_between(
        x[net_mask],
        y_roof[net_mask] * 0.001,
        y_roof[net_mask],
        color=colors["RedL"],
        alpha=0.5,
        label="Network-bound region",
    )
    ax.fill_between(
        x[comp_mask],
        y_roof[comp_mask] * 0.001,
        y_roof[comp_mask],
        color=colors["BlueFill"],
        alpha=0.5,
        label="Compute-bound region",
    )

    # Roofline line
    ax.loglog(
        x,
        y_roof,
        color=colors["VioletLine"],
        linewidth=2.5,
        zorder=5,
    )

    # Network bandwidth ceiling label
    slope_x = ridge_point * 0.08
    slope_y = peak_network_bw * slope_x / 1000
    ax.text(
        slope_x,
        slope_y * 1.6,
        f"Bisection BW: {peak_network_bw:.0f} GB/s",
        color=colors["RedLine"],
        fontsize=MIN_FONT_PT,
        fontweight="bold",
        rotation=38,
        ha="center",
        va="bottom",
    )

    # Fleet Compute ceiling label
    ax.text(
        x_max * 0.8,
        peak_flops * 1.12,
        f"Fleet Compute: {peak_flops:.0f} TFLOP/s",
        color=colors["BlueLine"],
        fontsize=MIN_FONT_PT,
        fontweight="bold",
        ha="right",
        va="bottom",
    )

    # Ridge point
    ax.plot(
        ridge_point,
        peak_flops,
        "X",
        color=colors["crimson"],
        markersize=10,
        zorder=10,
    )
    ax.annotate(
        f"Network Ridge\n{ridge_point:.1f} FLOP/Byte",
        xy=(ridge_point, peak_flops),
        xytext=(ridge_point * 2, peak_flops * 0.25),
        fontsize=MIN_FONT_PT,
        fontweight="bold",
        color=colors["crimson"],
        ha="center",
        arrowprops=dict(arrowstyle="->", color=colors["crimson"], lw=1.2),
    )

    # Region labels
    ax.text(
        x_min * 1.5,
        peak_flops * 0.6,
        "NETWORK\nBOUND",
        color=colors["RedLine"],
        fontsize=11,
        fontweight="bold",
        alpha=0.25,
        ha="left",
        va="center",
    )
    ax.text(
        x_max * 0.4,
        peak_flops * 0.6,
        "COMPUTE\nBOUND",
        color=colors["BlueLine"],
        fontsize=11,
        fontweight="bold",
        alpha=0.25,
        ha="right",
        va="center",
    )

    ax.set_xlabel("Communication Intensity (FLOP/Byte)")
    ax.set_ylabel("Fleet Performance (TFLOP/s)")
    ax.set_title(f"Distributed Roofline: {fleet_system.count}x {fleet_system.node.accelerator.name}")
    ax.set_xlim(x_min, x_max)
    ax.set_ylim(peak_flops * 0.001, peak_flops * 2)
    ax.legend(loc="lower right", fontsize=MIN_FONT_PT, framealpha=0.9)
    return _finalize_web_figure(fig), ax

def _metric_as_float(value, unit=None):
    """Return a numeric metric, converting Pint quantities when needed."""
    if hasattr(value, "m_as") and unit is not None:
        return float(value.m_as(unit))
    if hasattr(value, "to") and unit is not None:
        return float(value.to(unit).magnitude)
    if hasattr(value, "magnitude"):
        return float(value.magnitude)
    return float(value)

def _metric_ratio(numerator, denominator):
    """Return numerator / denominator for scalar or Pint quantity metrics."""
    if hasattr(numerator, "to") and hasattr(denominator, "units"):
        return float((numerator / denominator).to_base_units().magnitude)
    return float(numerator) / float(denominator)

def _memory_utilization(metrics):
    """Read or derive memory utilization from an evaluation metrics payload."""
    if "memory_utilization" in metrics:
        return float(metrics["memory_utilization"])
    if "weight_size" in metrics and "capacity" in metrics:
        return _metric_ratio(metrics["weight_size"], metrics["capacity"])
    if "memory_used_gb" in metrics and "memory_capacity_gb" in metrics:
        return _metric_ratio(metrics["memory_used_gb"], metrics["memory_capacity_gb"])
    return 0.0

def plot_evaluation_scorecard(evaluation):
    """
    Visualizes the supply-vs-demand scorecard for a SystemEvaluation.
    Follows the compact, labeled visualization pattern used by generated examples.
    """
    l1_metrics = evaluation.feasibility.metrics
    l2_metrics = evaluation.performance.metrics
    
    # 2. CALCULATION
    l1_ratio = _memory_utilization(l1_metrics)
    latency_ms = _metric_as_float(l2_metrics.get("latency", 0.0), "ms")
    sla_ms = _metric_as_float(
        l2_metrics.get("sla_latency_ms", l2_metrics.get("sla_latency", 1000.0)),
        "ms",
    )
    l2_ratio = latency_ms / sla_ms if sla_ms > 0 else 0.0
    
    levels = ['Memory (RAM)', 'Latency (SLA)']
    ratios = [l1_ratio, l2_ratio]
    
    # 3. OUTPUT (Visualization)
    fig, ax, colors, _plt = setup_plot(figsize=(BODY_FIGSIZE[0], 3.6))
    bar_colors = [colors['RedLine'] if r > 1.0 else colors['GreenLine'] for r in ratios]
    bars = ax.barh(levels, ratios, color=bar_colors, alpha=0.7, edgecolor='black')
    
    ax.axvline(1.0, color=colors['primary'], linestyle='--', linewidth=2, label='Physical Limit / SLA')
    
    for i, (bar, ratio) in enumerate(zip(bars, ratios)):
        ax.text(bar.get_width() + 0.05, bar.get_y() + bar.get_height()/2, f"{ratio:.1%}", 
                va='center', fontweight='bold', color=bar_colors[i])

    ax.set_xlim(0, max(max(ratios) + 0.5, 1.5))
    ax.set_xlabel('Resource Utilization (Demand / Supply)')
    ax.set_title(f'System Evaluation: {evaluation.scenario_name}')
    return _finalize_web_figure(fig), ax
