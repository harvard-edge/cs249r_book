#!/usr/bin/env python3
"""Report missing or weak provenance on registry entries."""

from __future__ import annotations

import argparse
import sys
from datetime import date
from typing import Any, Iterable

from mlsysim.core.provenance import Provenance, ProvenanceKind, Sourced
from mlsysim.datasets.registry import Datasets
from mlsysim.hardware.registry import (
    CloudHardware,
    EdgeHardware,
    MobileHardware,
    TinyHardware,
    WorkstationHardware,
)
from mlsysim.hardware.tech import (
    Battery,
    EffectiveCompute,
    Interconnect,
    Lithography,
    Memory,
    Movement,
    Op,
    Storage as TechStorage,
)
from mlsysim.infrastructure.registry import Datacenters, FacilityCooling, Grids, Racks
from mlsysim.infrastructure.pricing import Cloud, Storage, Labeling, Fleet, Capital, OnPremises
from mlsysim.infrastructure.capacity import Capacity
from mlsysim.literature.registry import Literature
from mlsysim.models.registry import (
    EmbodiedModels,
    GenerativeVisionModels,
    LanguageModels,
    RecommendationModels,
    StateSpaceModels,
    TinyModels,
    VisionModels,
)
from mlsysim.sensors.registry import Sensors
from mlsysim.actuators.registry import Actuators
from mlsysim.embodied.registry import Embodied
from mlsysim.agents.registry import Agents
from mlsysim.ops.monitoring import Monitoring
from mlsysim.ops.runtime import MemoryProtection, RuntimeOverheads
from mlsysim.ops.training import Preemption, TrainingRunOverheads
from mlsysim.platforms.registry import Platforms
from mlsysim.reference_stats.registry import ReferenceStats
from mlsysim.systems.registry import (
    Clusters,
    Fabrics,
    NetworkEnergy,
    Nodes,
    Pods,
    Racks as SystemRacks,
    Storage as SystemStorage,
    SwitchFabric,
)


def _registry_nodes(registry_cls: type) -> Iterable[Any]:
    """Yields all Sourced AST nodes found in the target registry file."""
    if not hasattr(registry_cls, "list"):
        return []
    return registry_cls.list()


def _validate_provenance_record(path: str, prov: Provenance | None) -> list[str]:
    """Validates that a Provenance record meets the required traceability constraints."""
    if prov is None:
        return [f"{path}: missing provenance"]
    issues: list[str] = []
    if not prov.ref.strip():
        issues.append(f"{path}: empty provenance.ref")
    if not prov.verified:
        issues.append(f"{path}: missing verified date")
    else:
        try:
            date.fromisoformat(prov.verified)
        except ValueError:
            issues.append(f"{path}: verified date must be YYYY-MM-DD")
    if prov.kind in {
        ProvenanceKind.DATASHEET,
        ProvenanceKind.LITERATURE,
        ProvenanceKind.INDUSTRY_REPORT,
    } and not prov.url:
        issues.append(f"{path}: {prov.kind.value} without url")
    if prov.kind in {ProvenanceKind.ESTIMATE, ProvenanceKind.DERIVED} and not prov.notes:
        issues.append(f"{path}: {prov.kind.value} without notes")
    return issues


def _check_node(path: str, node: Any) -> list[str]:
    """Inspects a runtime registry object to verify its provenance lineage."""
    meta = getattr(node, "metadata", None)
    if meta is not None:
        return _validate_provenance_record(path, getattr(meta, "provenance", None))
    if isinstance(node, Sourced):
        return _validate_provenance_record(path, node.provenance)
    if hasattr(node, "provenance"):
        return _validate_provenance_record(path, getattr(node, "provenance", None))
    if hasattr(node, "mttf_hours"):
        return _validate_provenance_record(path, getattr(node.mttf_hours, "provenance", None))
    if hasattr(node, "rate"):
        # Recurse into the rate VALUE (was `node`, an infinite loop — audit fix 2026-06-06).
        return _check_node(path, node.rate)
    # A value that reaches here carries no provenance hook at all. Report it
    # instead of silently passing (audit fix 2026-06-06: bare floats/Quantities
    # previously returned [] and made the "every value is sourced" claim
    # unenforced).
    return [f"{path}: no provenance attached ({type(node).__name__})"]


def audit_registries(*, scope_cloud: bool = False) -> list[str]:
    issues: list[str] = []
    groups = (
        [("Hardware.Cloud", CloudHardware)]
        if scope_cloud
        else [
            ("Hardware.Cloud", CloudHardware),
            ("Hardware.Workstation", WorkstationHardware),
            ("Hardware.Mobile", MobileHardware),
            ("Hardware.Edge", EdgeHardware),
            ("Hardware.Tiny", TinyHardware),
            ("Models.LanguageModels", LanguageModels),
            ("Models.VisionModels", VisionModels),
            ("Models.TinyModels", TinyModels),
            ("Models.RecommendationModels", RecommendationModels),
            ("Models.StateSpaceModels", StateSpaceModels),
            ("Models.GenerativeVisionModels", GenerativeVisionModels),
            ("Models.EmbodiedModels", EmbodiedModels),
        ]
    )
    for prefix, reg in groups:
        for node in _registry_nodes(reg):
            name = getattr(node, "name", type(node).__name__)
            issues.extend(_check_node(f"{prefix}.{name}", node))
    return issues


def audit_datasets() -> list[str]:
    issues: list[str] = []
    for dataset in _registry_nodes(Datasets):
        name = getattr(dataset, "name", type(dataset).__name__)
        issues.extend(_check_node(f"Datasets.{name}", dataset))
    return issues


def audit_platforms() -> list[str]:
    issues: list[str] = []
    for platform in _registry_nodes(Platforms):
        name = getattr(platform, "name", type(platform).__name__)
        issues.extend(_check_node(f"Platforms.{name}", platform))
    return issues


def audit_sensors() -> list[str]:
    issues: list[str] = []
    for sub in ("Camera", "LiDAR", "IMU", "SafetyScanner", "SafetyLightCurtain"):
        reg = getattr(Sensors, sub)
        for node in _registry_nodes(reg):
            name = getattr(node, "name", type(node).__name__)
            issues.extend(_check_node(f"Sensors.{sub}.{name}", node))
    return issues


def audit_actuators() -> list[str]:
    issues: list[str] = []
    for sub in ("HarmonicDrive", "QuasiDirectDrive", "Servo", "FramelessMotor", "PandaClassJoint", "HubMotor", "SafetyRelay"):
        reg = getattr(Actuators, sub)
        for node in _registry_nodes(reg):
            name = getattr(node, "name", type(node).__name__)
            issues.extend(_check_node(f"Actuators.{sub}.{name}", node))
    return issues


def audit_embodied() -> list[str]:
    issues: list[str] = []
    for sub in ("Quadruped", "Humanoid", "Manipulator", "Drone", "AMR", "Vehicle", "ContinuousProcess", "MobileManipulator", "Scenario"):
        reg = getattr(Embodied, sub)
        for node in _registry_nodes(reg):
            name = getattr(node, "name", type(node).__name__)
            issues.extend(_check_node(f"Embodied.{sub}.{name}", node))
    return issues


def audit_agents() -> list[str]:
    issues: list[str] = []
    for sub in ("Coding", "Deliberation", "MultiAgent", "Interactive", "Research", "Remediation", "Support"):
        reg = getattr(Agents, sub)
        for node in _registry_nodes(reg):
            name = getattr(node, "name", type(node).__name__)
            issues.extend(_check_node(f"Agents.{sub}.{name}", node))
    return issues


def audit_hardware_tech() -> list[str]:
    issues: list[str] = []
    for prefix, reg in (
        ("Hardware.Tech.Memory", Memory),
        ("Hardware.Tech.Storage", TechStorage),
        ("Hardware.Tech.Op", Op),
        ("Hardware.Tech.EffectiveCompute", EffectiveCompute),
        ("Hardware.Tech.Movement", Movement),
        ("Hardware.Tech.Interconnect", Interconnect),
        ("Hardware.Tech.Lithography", Lithography),
        ("Hardware.Tech.Battery", Battery),
    ):
        for node in _registry_nodes(reg):
            name = getattr(node, "name", type(node).__name__)
            issues.extend(_check_node(f"{prefix}.{name}", node))
    return issues


def audit_systems_topology() -> list[str]:
    issues: list[str] = []
    for prefix, reg in (
        ("Systems.Nodes", Nodes),
        ("Systems.Fabrics", Fabrics),
        ("Systems.Clusters", Clusters),
        ("Systems.Pods", Pods),
        ("Systems.Racks", SystemRacks),
        ("Systems.Storage", SystemStorage),
    ):
        for node in _registry_nodes(reg):
            name = getattr(node, "name", type(node).__name__)
            issues.extend(_check_node(f"{prefix}.{name}", node))
    return issues


def audit_systems_reference_values() -> list[str]:
    issues: list[str] = []
    for prefix, reg in (
        ("Systems.SwitchFabric", SwitchFabric),
        ("Systems.NetworkEnergy", NetworkEnergy),
    ):
        for node in _registry_nodes(reg):
            name = getattr(node, "name", type(node).__name__)
            issues.extend(_check_node(f"{prefix}.{name}", node))
    return issues


def audit_infra_grids() -> list[str]:
    issues: list[str] = []
    for grid in _registry_nodes(Grids):
        name = getattr(grid, "name", type(grid).__name__)
        issues.extend(_check_node(f"Infrastructure.Grids.{name}", grid))
    return issues


def audit_infra_facilities() -> list[str]:
    issues: list[str] = []
    for prefix, reg in (
        ("Infrastructure.Datacenters", Datacenters),
        ("Infrastructure.Racks", Racks),
        ("Infrastructure.FacilityCooling", FacilityCooling),
    ):
        for node in _registry_nodes(reg):
            name = getattr(node, "name", type(node).__name__)
            issues.extend(_check_node(f"{prefix}.{name}", node))
    from mlsysim.infrastructure.registry import AIR_COOLING_LIMIT_KW
    issues.extend(_check_node("Infrastructure.AIR_COOLING_LIMIT_KW", AIR_COOLING_LIMIT_KW))
    return issues


def audit_infra_pricing() -> list[str]:
    issues: list[str] = []
    for prefix, reg in (
        ("Infrastructure.Pricing.Cloud", Cloud),
        ("Infrastructure.Pricing.Storage", Storage),
        ("Infrastructure.Pricing.Labeling", Labeling),
        ("Infrastructure.Pricing.Fleet", Fleet),
        ("Infrastructure.Pricing.Capital", Capital),
        ("Infrastructure.Pricing.OnPremises", OnPremises),
    ):
        for point in _registry_nodes(reg):
            name = getattr(point, "name", type(point).__name__)
            issues.extend(_check_node(f"{prefix}.{name}", point))
    return issues


def audit_infra_capacity() -> list[str]:
    issues: list[str] = []
    for val in _registry_nodes(Capacity):
        if isinstance(val, Sourced):
            issues.extend(_validate_provenance_record("Infrastructure.Capacity", val.provenance))
    return issues


def audit_literature_sourced() -> list[str]:
    issues: list[str] = []
    for attr in sorted(dir(Literature)):
        if attr.startswith("_") or attr in ("list", "get", "names"):
            continue
        obj = getattr(Literature, attr)
        if hasattr(obj, "provenance"):
            issues.extend(_validate_provenance_record(f"Literature.{attr}", obj.provenance))
        elif hasattr(obj, "list"):
            for item in _registry_nodes(obj):
                if isinstance(item, Sourced):
                    issues.extend(_validate_provenance_record(f"Literature.{attr}", item.provenance))
    return issues


def audit_reference_stats() -> list[str]:
    issues: list[str] = []
    for item in _registry_nodes(ReferenceStats):
        name = getattr(item, "name", type(item).__name__)
        issues.extend(_check_node(f"ReferenceStats.{name}", item))
    return issues


def audit_ops_sourced() -> list[str]:
    issues: list[str] = []
    for prefix, reg in (
        ("Ops.Monitoring", Monitoring),
        ("Ops.RuntimeOverheads", RuntimeOverheads),
        ("Ops.MemoryProtection", MemoryProtection),
        ("Ops.TrainingRunOverheads", TrainingRunOverheads),
        ("Ops.Preemption", Preemption),
    ):
        for item in _registry_nodes(reg):
            name = getattr(item, "name", type(item).__name__)
            issues.extend(_check_node(f"{prefix}.{name}", item))
    return issues


def audit_calibration_sourced() -> list[str]:
    issues: list[str] = []
    from mlsysim.engine import calibration as cal

    for name in dir(cal):
        if name.startswith("_"):
            continue
        val = getattr(cal, name)
        if isinstance(val, Sourced):
            issues.extend(
                _validate_provenance_record(f"engine.calibration.{name}", val.provenance)
            )
    return issues


def audit_systems_reliability() -> list[str]:
    from mlsysim.systems.reliability import Reliability

    issues: list[str] = []
    for comp in _registry_nodes(Reliability):
        if hasattr(comp, "name"):
            issues.extend(_check_node(f"Systems.Reliability.{comp.name}", comp))
    recovery = Reliability.Recovery
    for field in (
        "heartbeat_timeout_s",
        "reschedule_time_s",
        "detection_time_s",
        "restart_time_s",
        "warmup_time_s",
        "checkpoint_write_bw_gbs",
    ):
        val = getattr(recovery, field)
        if isinstance(val, Sourced):
            issues.extend(
                _validate_provenance_record(f"Systems.Reliability.Recovery.{field}", val.provenance)
            )
    return issues


def audit_tier2_book_series() -> list[str]:
    """Audit all Tier-2 empirical CSV series under ``books/vol*/**/data/*.csv``."""
    from pathlib import Path
    from mlsysim.core.series_loader import LocalSeries

    repo_root = Path(__file__).resolve().parents[3]
    books_dir = repo_root / "books"
    if not books_dir.is_dir():
        return []

    import json

    valid_epistemic = {"measured", "modeled", "assumed", "constructed"}
    valid_methods = {"transcribed", "digitized", "scripted", "derived"}
    manifest_by_path: dict[str, dict] = {}
    manifest_path = books_dir / "datapackage.json"
    if manifest_path.is_file():
        try:
            pkg = json.loads(manifest_path.read_text(encoding="utf-8"))
            manifest_by_path = {
                r["path"]: r
                for r in pkg.get("resources", [])
                if isinstance(r, dict) and isinstance(r.get("path"), str)
            }
        except Exception as exc:
            issues_init = [f"books/datapackage.json: invalid JSON ({exc})"]
        else:
            issues_init = []
    else:
        issues_init = ["books/datapackage.json: missing Frictionless manifest"]

    issues: list[str] = list(issues_init)
    for csv_path in sorted(books_dir.rglob("data/*.csv")):
        rel_parts = csv_path.relative_to(books_dir).parts
        if not rel_parts or not rel_parts[0].startswith("vol"):
            continue
        if any(p.startswith(".") or p in {"_build", "_book"} or p.endswith("_files") for p in rel_parts):
            continue
        label = f"Tier2Series.{csv_path.relative_to(repo_root)}"
        series = LocalSeries(csv_path)
        prov = series.provenance
        for req_field, req_header in (
            ("figures", "# Figures:"),
            ("source", "# Source:"),
            ("locator", "# Locator:"),
            ("url", "# URL:"),
            ("license", "# License:"),
        ):
            if not prov.get(req_field, "").strip():
                issues.append(f"{label}: missing '{req_header}' header")
        if "@" not in " ".join(prov.get(k, "") for k in ("source", "locator", "computation", "notes")):
            issues.append(f"{label}: '# Source:' must cite at least one verified @bibkey")
        verified = prov.get("verified", "").strip()
        if not verified:
            issues.append(f"{label}: missing '# Verified: YYYY-MM-DD' header")
        else:
            try:
                vdate = date.fromisoformat(verified)
                if vdate < date(2020, 1, 1) or vdate > date.today():
                    issues.append(f"{label}: '# Verified: {verified}' out of valid date range")
            except ValueError:
                issues.append(f"{label}: '# Verified: {verified}' must be YYYY-MM-DD")
        if not prov.get("computation", "").strip() and not prov.get("notes", "").strip():
            issues.append(f"{label}: missing both '# Computation:' and '# Notes:' headers")
        epistemic = prov.get("epistemic", "").strip()
        if not epistemic:
            issues.append(f"{label}: missing '# Epistemic:' header")
        else:
            head = epistemic.replace("(", " ").replace(";", " ").replace(",", " ").split()[0].lower()
            if head not in valid_epistemic:
                issues.append(f"{label}: '# Epistemic:' must start with {sorted(valid_epistemic)}")
        method = prov.get("method", "").strip()
        if not method:
            issues.append(f"{label}: missing '# Method:' header")
        else:
            mhead = method.replace("(", " ").replace(";", " ").replace(",", " ").split()[0].lower()
            if mhead not in valid_methods:
                issues.append(f"{label}: '# Method:' must start with {sorted(valid_methods)}")
        if tuple(c.name for c in series.column_schema) != series.columns:
            issues.append(f"{label}: '# Columns:' schema does not match CSV header {list(series.columns)}")
        rel_books = csv_path.relative_to(books_dir).as_posix()
        sealed = manifest_by_path.get(rel_books)
        if manifest_by_path and sealed is None:
            issues.append(f"{label}: unsealed in books/datapackage.json")
        elif sealed is not None:
            if sealed.get("hash") != f"sha256:{series.file_sha256}":
                issues.append(f"{label}: SHA-256 drifted from books/datapackage.json")
            if (sealed.get("custom") or {}).get("data_sha256") != series.data_sha256:
                issues.append(f"{label}: data_sha256 drifted from books/datapackage.json")
    return issues


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--scope",
        choices=("cloud", "all"),
        default="all",
        help="What to scan",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Exit 1 when any issue is found",
    )
    args = parser.parse_args(argv)

    issues: list[str] = []
    if args.scope == "cloud":
        issues.extend(audit_registries(scope_cloud=True))
    if args.scope == "all":
        issues.extend(audit_registries(scope_cloud=False))
        issues.extend(audit_datasets())
        issues.extend(audit_platforms())
        issues.extend(audit_sensors())
        issues.extend(audit_actuators())
        issues.extend(audit_embodied())
        issues.extend(audit_agents())
        issues.extend(audit_hardware_tech())
        issues.extend(audit_systems_topology())
        issues.extend(audit_systems_reference_values())
        issues.extend(audit_infra_grids())
        issues.extend(audit_infra_facilities())
        issues.extend(audit_infra_pricing())
        issues.extend(audit_infra_capacity())
        issues.extend(audit_literature_sourced())
        issues.extend(audit_reference_stats())
        issues.extend(audit_ops_sourced())
        issues.extend(audit_systems_reliability())
        issues.extend(audit_calibration_sourced())
        issues.extend(audit_tier2_book_series())

    if issues:
        print(f"Provenance audit ({args.scope}): {len(issues)} issue(s)")
        for line in sorted(issues):
            print(f"  - {line}")
        return 1 if args.strict else 0

    print(f"Provenance audit OK (scope={args.scope}).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
