import json
from typing import Any
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

# Strict I/O Purity (Guideline 1)
console_err = Console(stderr=True) # All diagnostics, warnings, UI go to stderr
console_out = Console()            # stdout is reserved for the final payload


def _json_safe(value: Any) -> Any:
    """Recursively convert quantities and rich objects into JSON-safe values."""
    if isinstance(value, dict):
        return {k: _json_safe(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_json_safe(v) for v in value]
    if isinstance(value, tuple):
        return [_json_safe(v) for v in value]
    # Duck-typed Pint Quantity check (avoids importing the registry here);
    # serialize as the compact pretty string ("3.35 TB/s") so the unit travels
    # with the number in JSON output.
    if hasattr(value, "magnitude") and hasattr(value, "units"):
        return f"{value:~P}"
    return value


def print_json(payload: Any) -> None:
    """Print strict JSON that rejects NaN/Infinity."""
    print(json.dumps(_json_safe(payload), indent=2, allow_nan=False))


def print_error(title: str, message: str, output_format: str = "text"):
    """Renders a semantic error box, or a JSON error."""
    if output_format == "json":
        # If in JSON mode, we still print the error to stdout so the script can parse the failure reason
        print(json.dumps({"status": "error", "title": title, "reason": message}))
    elif output_format == "markdown":
        console_err.print(f"**{title}**\n\n{message}")
    else:
        console_err.print(Panel(message, title=f"[bold red]{title}[/bold red]", border_style="red"))

def print_warning(message: str):
    """Warnings ALWAYS go to stderr so they don't break JSON pipes."""
    console_err.print(f"[bold yellow]WARNING:[/bold yellow] {message}")

def render_zoo_table(registry_name: str, items: list, output_format: str):
    """Renders a registry listing (Zoo) as a table or JSON."""
    if output_format == "json":
        # Extract primitive data for JSON dump
        data = []
        for item in items:
            row = {"name": item.name}
            if hasattr(item, "compute"):
                row["flops"] = str(item.compute.peak_flops)
                row["bandwidth"] = str(item.memory.bandwidth)
            elif hasattr(item, "parameters"):
                params = getattr(item, "parameters", None)
                row["architecture"] = getattr(item, "architecture", None)
                row["parameters"] = str(params) if params is not None else None
                row["layers"] = getattr(item, "layers", None)
            data.append(row)
        print_json({registry_name: data})
        return
    elif output_format == "markdown":
        print(f"## The MLSys {registry_name.title()} Zoo\n")
        if items and hasattr(items[0], "compute"):
            print("| Hardware Name | Peak FLOP/s | HBM Bandwidth | TDP |")
            print("|---|---|---|---|")
            for item in items:
                tdp_str = str(item.tdp) if item.tdp else "N/A"
                print(f"| {item.name} | {item.compute.peak_flops:~P} | {item.memory.bandwidth:~P} | {tdp_str} |")
        elif items and hasattr(items[0], "parameters"):
            print("| Model Name | Architecture | Parameters | Layers |")
            print("|---|---|---|---|")
            for item in items:
                layers_str = str(getattr(item, "layers", "-") or "-")
                params = getattr(item, "parameters", None)
                params_str = f"{params:~P}" if hasattr(params, "magnitude") else (str(params) if params is not None else "-")
                print(f"| {item.name} | {item.architecture} | {params_str} | {layers_str} |")
        return

    table = Table(title=f"The MLSys {registry_name.title()} Zoo", box=None, padding=(0, 2))

    if items and hasattr(items[0], "compute"):
        table.add_column("Hardware Name", style="cyan", no_wrap=True)
        table.add_column("Peak FLOP/s", justify="right", style="green")
        table.add_column("HBM Bandwidth", justify="right", style="magenta")
        table.add_column("TDP", justify="right")
        for item in items:
            tdp_str = str(item.tdp) if item.tdp else "N/A"
            table.add_row(item.name, f"{item.compute.peak_flops:~P}", f"{item.memory.bandwidth:~P}", tdp_str)

    elif items and hasattr(items[0], "parameters"):
        table.add_column("Model Name", style="cyan", no_wrap=True)
        table.add_column("Architecture", style="white")
        table.add_column("Parameters", justify="right", style="green")
        table.add_column("Layers", justify="right")
        for item in items:
            layers_str = str(getattr(item, 'layers', '-') or '-')
            params_str = f"{item.parameters:~P}" if hasattr(item.parameters, 'magnitude') else str(item.parameters)
            table.add_row(item.name, getattr(item, 'architecture', '-'), params_str, layers_str)

    console_out.print(table)

def render_scorecard(eval_obj, output_format: str):
    """Renders the unified 3-lens SystemEvaluation scorecard."""

    def _format_metric(k: str, v: Any) -> str:
        """Format a scalar metric for CLI rendering, with a unit chosen by key.

        Units are matched on exact word/suffix boundaries of the snake_case
        key (e.g. ``step_latency`` -> " ms") rather than substring containment,
        so a key like ``memory_utilization`` can never pick up a " GB" suffix.
        Keys whose unit is not recognized render as a bare number — matching
        the metric dicts built in ``engine/evaluation.py``, where e.g.
        ``scaling_efficiency`` and ``memory_utilization`` are dimensionless.
        """
        def _word_match(key: str, word: str) -> bool:
            parts = key.lower().split("_")
            return word in parts

        if isinstance(v, float):
            if _word_match(k, "mfu"):
                return f"{v:.1%}"
            val = f"{v:,.2f}"
            if _word_match(k, "latency"):
                val += " ms"
            elif _word_match(k, "throughput"):
                val += " / s"
            elif _word_match(k, "memory") and _word_match(k, "gb"):
                val += " GB"
            return val
        return f"{v}"

    if output_format == "json":
        # Machine Mode: stdout gets strict JSON
        print_json(eval_obj.to_dict())
        return
    elif output_format == "markdown":
        print(f"## MLSys·im Plan: {eval_obj.scenario_name}")

        f_icon = "🟢" if eval_obj.feasibility.status == "PASS" else "🔴"
        print(f"\n### {f_icon} Feasibility: {eval_obj.feasibility.status}")
        print(f"{eval_obj.feasibility.summary}")

        print(f"\n### Performance: {eval_obj.performance.status}")
        print(f"{eval_obj.performance.summary}")
        for k, v in eval_obj.performance.metrics.items():
            print(f"- **{k.replace('_', ' ').title()}**: {_format_metric(k, v)}")

        if eval_obj.macro.status != "SKIPPED":
            print(f"\n### Ops & Macro: {eval_obj.macro.status}")
            print(f"{eval_obj.macro.summary}")
            for k, v in eval_obj.macro.metrics.items():
                print(f"- **{k.replace('_', ' ').title()}**: {_format_metric(k, v)}")
        return
    elif output_format == "html":
        # Generate a standalone HTML dashboard.
        f_icon = "🟢" if eval_obj.feasibility.status == "PASS" else "🔴"
        f_color = "#10b981" if eval_obj.feasibility.status == "PASS" else "#ef4444"

        perf_html = "".join([f"<tr><td style='padding:8px; border-bottom:1px solid #eee;'><b>{k.replace('_', ' ').title()}</b></td><td style='padding:8px; border-bottom:1px solid #eee; text-align:right;'>{_format_metric(k, v)}</td></tr>" for k, v in eval_obj.performance.metrics.items()])

        macro_html = ""
        if eval_obj.macro.status != "SKIPPED":
            macro_rows = "".join([f"<tr><td style='padding:8px; border-bottom:1px solid #eee;'><b>{k.replace('_', ' ').title()}</b></td><td style='padding:8px; border-bottom:1px solid #eee; text-align:right;'>{_format_metric(k, v)}</td></tr>" for k, v in eval_obj.macro.metrics.items()])
            macro_html = f"""
            <div class="card" style="border-left: 4px solid #8b5cf6;">
                <h3 style="color:#8b5cf6;">Ops & Macro: {eval_obj.macro.status}</h3>
                <p>{eval_obj.macro.summary}</p>
                <table style="width:100%; border-collapse:collapse; font-size:14px; margin-top:15px;">{macro_rows}</table>
            </div>
            """

        html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>MLSys·im Plan: {eval_obj.scenario_name}</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background-color: #f9fafb; color: #111827; padding: 40px; line-height: 1.5; }}
        .container {{ max-width: 600px; margin: 0 auto; }}
        .card {{ background: white; padding: 24px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 20px; }}
        h2 {{ color: #1f2937; text-align: center; margin-bottom: 30px; }}
        h3 {{ margin-top: 0; margin-bottom: 8px; font-size: 18px; }}
        p {{ margin-top: 0; color: #4b5563; font-size: 14px; }}
    </style>
</head>
<body>
    <div class="container">
        <h2>MLSys·im Plan<br><span style="color:#6b7280; font-size:18px; font-weight:normal;">{eval_obj.scenario_name}</span></h2>

        <div class="card" style="border-left: 4px solid {f_color};">
            <h3 style="color:{f_color};">{f_icon} Feasibility: {eval_obj.feasibility.status}</h3>
            <p>{eval_obj.feasibility.summary}</p>
        </div>

        <div class="card" style="border-left: 4px solid #3b82f6;">
            <h3 style="color:#3b82f6;">Performance: {eval_obj.performance.status}</h3>
            <p>{eval_obj.performance.summary}</p>
            <table style="width:100%; border-collapse:collapse; font-size:14px; margin-top:15px;">
                {perf_html}
            </table>
        </div>

        {macro_html}
    </div>
</body>
</html>"""
        print(html_content)
        return

    # Human Mode: Render the UI Scorecard
    # We use the unified scorecard() method from the core library to ensure
    # the CLI matches the notebook scorecard output exactly.
    console_out.print(eval_obj.scorecard())


def render_optimization(opt_name: str, opt_result, output_format: str):
    """Renders the output of any OptimizationResult (engine or core protocol)."""
    if output_format == "json":
        if hasattr(opt_result, "model_dump"):
            print_json(opt_result.model_dump(mode="python"))
        else:
            from dataclasses import asdict, is_dataclass
            print_json(asdict(opt_result) if is_dataclass(opt_result) else dict(opt_result))
        return

    objective_val = float(
        getattr(opt_result, "objective_value", getattr(opt_result, "optimal_objective", 0.0))
    )
    best_cfg = getattr(opt_result, "best_config", getattr(opt_result, "optimal_point", {}))
    searched = int(
        getattr(opt_result, "total_searched", getattr(opt_result, "evaluations", 0))
    )

    if output_format == "markdown":
        print(f"## MLSys·im Optimize: {opt_name}")
        print(f"\n### Objective Value: {objective_val:,.2f}")
        print("\n### Best Configuration")
        for k, v in best_cfg.items():
            print(f"- **{k.replace('_', ' ').title()}**: {v}")
        print(f"\n*Searched {searched} configurations.*")
        return
    elif output_format == "html":
        config_html = "".join([f"<tr><td style='padding:8px; border-bottom:1px solid #eee;'><b>{k.replace('_', ' ').title()}</b></td><td style='padding:8px; border-bottom:1px solid #eee; text-align:right;'>{v}</td></tr>" for k, v in best_cfg.items()])

        html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>MLSys·im Optimize: {opt_name}</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background-color: #f9fafb; color: #111827; padding: 40px; line-height: 1.5; }}
        .container {{ max-width: 600px; margin: 0 auto; }}
        .card {{ background: white; padding: 24px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 20px; }}
        h2 {{ color: #1f2937; text-align: center; margin-bottom: 30px; }}
        h3 {{ margin-top: 0; margin-bottom: 8px; font-size: 18px; }}
    </style>
</head>
<body>
    <div class="container">
        <h2>🔍 MLSys·im Optimize<br><span style="color:#6b7280; font-size:18px; font-weight:normal;">{opt_name}</span></h2>

        <div class="card" style="border-left: 4px solid #06b6d4; text-align: center;">
            <h3 style="color:#06b6d4; font-size: 14px; text-transform: uppercase; letter-spacing: 1px;">Objective Value</h3>
            <div style="font-size: 32px; font-weight: bold; color: #111827;">{objective_val:,.2f}</div>
        </div>

        <div class="card" style="border-left: 4px solid #10b981;">
            <h3 style="color:#10b981;">Best Configuration</h3>
            <table style="width:100%; border-collapse:collapse; font-size:14px; margin-top:15px; margin-bottom: 15px;">
                {config_html}
            </table>
            <p style="color: #6b7280; font-size: 12px; margin-bottom: 0; text-align: center;">
                <i>Searched {searched} configurations.</i>
            </p>
        </div>
    </div>
</body>
</html>"""
        print(html_content)
        return

    table = Table(show_header=False, box=None, padding=(0, 2))

    table.add_row("[bold cyan]Objective Value[/bold cyan]", f"{objective_val:,.2f}")
    table.add_row("", "")

    table.add_row("[bold green]Best Configuration[/bold green]", "")
    for k, v in best_cfg.items():
        table.add_row(f"  • {k.replace('_', ' ').title()}", f"{v}")

    table.add_row("", "")
    table.add_row(f"[italic gray]Searched {searched} configurations.[/italic gray]", "")

    panel = Panel(
        table,
        title=f"[bold]MLSys·im Optimize: {opt_name}[/bold]",
        border_style="cyan",
        expand=False
    )

    console_out.print(panel)
