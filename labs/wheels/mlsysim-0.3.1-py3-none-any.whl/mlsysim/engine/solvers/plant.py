"""Physical-plant solvers: the stopping, actuation, heat, and power budgets of an
embodied machine (added 2026-10-20).

Domain implementations behind ``mlsysim.solvers`` (the public import path,
derived from ``engine.solvers.__init__``). Each model takes stated inputs and
returns every intermediate a budget quotes, so a chapter, a slide deck, and a
lab read the same arithmetic. The equations themselves live in ``physics/``
(``robotics/stopping.py``, ``drivetrain.py``, ``motors.py``); these models only
compose them into the budgets of one machine.
"""

from __future__ import annotations

import math
from typing import Dict, Iterable, Optional, Sequence, Tuple

from ..results import (
    BrakingCeilingsResult,
    ContinuousDeratingResult,
    DriveBusResult,
    FreshnessProfileResult,
    GearedRotorResult,
    GearRatioCostResult,
    HubDriveElectricalResult,
    SpeedStepResult,
    StallDeratingResult,
    ThermalBurstResult,
    ThrottledStageResult,
    ZeroFailureResult,
    ExponentialRareEventResult,
    DiagnosticCoverageResult,
)
from ...core.types import Quantity
from ...core.units import ureg
from ...physics.constants import COPPER_TEMPERATURE_COEFFICIENT, COPPER_COEFFICIENT_REFERENCE_TEMPERATURE
from ...physics.drivetrain import (
    calc_braking_limits,
    calc_drive_torque_deceleration_limit,
    calc_drive_voltage_headroom,
    calc_required_friction,
    calc_traction_deceleration_limit,
)
from ...physics.motors import (
    calc_copper_resistance_factor,
    calc_first_order_time_to_temperature,
    calc_inertia_matched_ratio,
    calc_peak_normalized_response,
    calc_periodic_burst_peak_rise,
)
from ...physics.robotics.actuation import calc_kinetic_energy, calc_reflected_inertia, calc_voltage_droop
from ...physics.robotics.assurance import (
    calc_clopper_pearson_zero_failure_bound,
    calc_zero_failure_rate_upper_bound,
    calc_zero_failure_sample_size,
)
from ...physics.statistics import (
    calc_cross_entropy_exponential_proposal,
    calc_importance_sampling_exponential,
    calc_monte_carlo_sample_size,
    calc_optimal_exponential_proposal_mean,
)
from .base import ForwardModel

_MM = ureg.millimeter
_MS = ureg.millisecond
_K = ureg.kelvin


def _ratio(a, b) -> float:
    return float((a / b).to("").magnitude)


class SpeedStepModel(ForwardModel):
    """
    Braking travel added by raising the speed setpoint, and the delay that costs the same distance.

    Braking travel grows as v^2; the added travel divided by the base speed is
    the pre-brake delay that would cost the same distance at the base speed.
    """
    requires = ()
    produces = SpeedStepResult

    def solve(self, base_speed: Quantity, raised_speed: Quantity, deceleration: Quantity) -> SpeedStepResult:
        """Braking travel added by raising the speed setpoint, and the delay that costs the same distance.

        Parameters
        ----------
        base_speed : Quantity
            Positive initial speed (m/s).
        raised_speed : Quantity
            Comparison speed (m/s).
        deceleration : Quantity
            Positive constant braking magnitude (m/s^2).

        Returns
        -------
        SpeedStepResult
            Added braking distance in mm and equivalent delay in ms; fractional growth is dimensionless.

        Notes
        -----
        Equation: For speeds v0 and v1 and positive deceleration a, d0 = v0^2/(2a), d1 = v1^2/(2a), added = d1-d0, growth = d1/d0-1, and equivalent delay = added/v0.

        Assumptions: Fixed deceleration at both speeds.

        Excludes: Brake ramps, tire slip, and controller delay.

        References
        ----------
        Derivation: Integrating constant deceleration gives stopping time v/a and mean speed v/2. Their product is the stopping distance; divide the difference of two distances by the original speed to express it as delay.

        Examples
        --------
        >>> from mlsysim.core.units import Q_ as Q
        >>> SpeedStepModel().solve(Q("1 m/s"), Q("2 m/s"), Q("1 m/s^2")).braking_added.magnitude > 0
        True
        """
        base = (base_speed ** 2 / (2 * deceleration)).to(_MM)
        raised = (raised_speed ** 2 / (2 * deceleration)).to(_MM)
        added = (raised - base).to(_MM)
        return SpeedStepResult(braking_growth=_ratio(raised, base) - 1, braking_added=added,
                               equivalent_delay=(added / base_speed).to(_MS))


class FreshnessProfileModel(ForwardModel):
    """
    A moving target's freshness deadline against a capture-to-onset age profile.

    The deadline is the tolerance left after the initial error, divided by the
    target speed: Delta t_fresh = (r_tol - e_0) / v. Stage percentiles are
    summed per percentile; the target's travel at the median chain and at the
    system tail age is compared with the allowed error.
    """
    requires = ()
    produces = FreshnessProfileResult

    def solve(self, target_speed: Quantity, tolerance: Quantity, initial_error: Quantity,
              stages: Sequence[Tuple[str, Quantity, Quantity, Quantity]], focus_stage: str,
              tail_age: Quantity) -> FreshnessProfileResult:
        """A moving target's freshness deadline against a capture-to-onset age profile.

        Parameters
        ----------
        target_speed : Quantity
            Positive target speed (m/s).
        tolerance : Quantity
            Allowed position error (m).
        initial_error : Quantity
            Position error before motion (m).
        stages : Sequence[Tuple[str, Quantity, Quantity, Quantity]]
            Sequence of (name, median, p99, maximum), with times in seconds.
        focus_stage : str
            Name present in stages whose median is inspected.
        tail_age : Quantity
            Separately supplied end-to-end tail age (s).

        Returns
        -------
        FreshnessProfileResult
            Allowed error and travel in mm, age/deadline in ms, and focus rate in Hz.

        Notes
        -----
        Equation: Remaining position allowance r = tolerance-initial_error gives deadline r/target_speed. Each stage column is summed separately. Travel at age t is ``target_speed*t``; slack is r-travel.

        Assumptions: Constant target speed; stage quantiles are added as a budgeting convention, not as a probabilistic convolution.

        Excludes: Correlation modeling and a guarantee that summed p99 values equal end-to-end p99.

        References
        ----------
        Derivation: A constant-speed target consumes position allowance linearly with age. Stage-quantile sums are a declared budget construction, while tail_age is a separate end-to-end input; summing marginal quantiles does not derive a joint quantile.

        Examples
        --------
        >>> from mlsysim.core.units import Q_ as Q
        >>> FreshnessProfileModel().solve(Q("1 m/s"), Q("1 m"), Q("0.1 m"), [("sensor", Q("0.01 s"), Q("0.02 s"), Q("0.03 s"))], "sensor", Q("0.04 s")).deadline.magnitude > 0
        True
        """
        allowed = (tolerance - initial_error).to(_MM)
        p50 = sum((s[1] for s in stages), 0 * _MS).to(_MS)
        p99 = sum((s[2] for s in stages), 0 * _MS).to(_MS)
        pmax = sum((s[3] for s in stages), 0 * _MS).to(_MS)
        focus = next(s[1] for s in stages if s[0] == focus_stage).to(_MS)
        t50 = (target_speed * p50).to(_MM)
        ttail = (target_speed * tail_age).to(_MM)
        return FreshnessProfileResult(
            allowed_error=allowed, deadline=(allowed / target_speed).to(_MS),
            stage_sum_p50=p50, stage_sum_p99=p99, stage_sum_max=pmax,
            focus_stage=focus, rest_of_chain=(p50 - focus).to(_MS), focus_share=_ratio(focus, p50),
            focus_rate=(1 / focus).to(ureg.hertz),
            travel_p50=t50, travel_tail=ttail, slack_p50=(allowed - t50).to(_MM), overrun_tail=(ttail - allowed).to(_MM),
        )


class BrakingCeilingsModel(ForwardModel):
    """
    The three ceilings on a credible deceleration (traction, tip-over, drive torque) and back-EMF headroom.

    Composes ``calc_braking_limits`` for a wheeled base driven by direct-drive
    hub motors at a configured current limit, adds the rated-current torque
    ceiling and the inspected-floor traction ceiling (all weight on the driven
    wheels), and checks the terminal voltage braking and driving need at speed.
    """
    requires = ()
    produces = BrakingCeilingsResult

    def solve(self, mass: Quantity, deceleration: Quantity, speed: Quantity, hub, n_wheels: int,
              current_limit: Quantity, drive_load_share: float, mu_dry: float, mu_inspected: float,
              bus_low: Quantity, cg_height: Optional[Quantity] = None,
              tip_arm: Optional[Quantity] = None) -> BrakingCeilingsResult:
        """The three ceilings on a credible deceleration (traction, tip-over, drive torque) and back-EMF headroom.

        Parameters
        ----------
        mass : Quantity
            Positive translated mass (kg).
        deceleration : Quantity
            Requested positive deceleration (m/s^2).
        speed : Quantity
            Forward speed (m/s).
        hub : object
            Motor specification with wheel radius, torque constant, rotating mass bound, rated torque, back-EMF constant, and line resistance.
        n_wheels : int
            Positive driven wheel count.
        current_limit : Quantity
            Per-wheel current limit (A).
        drive_load_share : float
            Fraction of normal load carried by driven wheels, in (0, 1].
        mu_dry : float
            Positive dry-floor friction coefficient.
        mu_inspected : float
            Positive inspected-floor friction coefficient.
        bus_low : Quantity
            Available bus voltage (V).
        cg_height : Optional[Quantity]
            Optional positive center-of-gravity height (m).
        tip_arm : Optional[Quantity]
            Optional positive support-polygon tipping arm (m).

        Returns
        -------
        BrakingCeilingsResult
            Forces in N, deceleration ceilings in m/s^2, wheel torque in N*m, voltage headroom in V.

        Notes
        -----
        Equation: Per-wheel torque is ``Kt*current_limit``. Effective mass is ``mass+n_wheels*rotating_mass_bound``; torque-limited deceleration is ``n_wheels*torque/(radius*effective_mass)``. Traction limits are ``mu*g*drive_load_share``. Tip-over and voltage checks compose calc_braking_limits and calc_drive_voltage_headroom.

        Assumptions: Quasistatic traction and rigid-body torque limits; identical wheel drives.

        Excludes: Dynamic load transfer, tire dynamics, and safety certification.

        References
        ----------
        Derivation: Wheel torque divided by radius gives longitudinal force; dividing by effective mass gives deceleration. Friction bounds that force by normal load times friction coefficient. See mlsysim.physics.drivetrain.calc_braking_limits for the tipping constraint and mlsysim.physics.drivetrain.calc_drive_voltage_headroom for the electrical convention.

        Examples
        --------
        >>> from mlsysim.core.units import Q_ as Q
        >>> from types import SimpleNamespace
        >>> hub = SimpleNamespace(wheel_radius=Q("0.1 m"), torque_constant=Q("1 N*m/A"), rotating_mass_bound=Q("1 kg"), rated_torque=Q("1 N*m"), peak_torque=Q("2 N*m"), back_emf_constant=Q("1 V*s/rad"), line_resistance=Q("1 ohm"), line_inductance=Q("0.001 H"), peak_current=Q("20 A"), pole_pairs=10)
        >>> BrakingCeilingsModel().solve(Q("100 kg"), Q("1 m/s^2"), Q("1 m/s"), hub, 2, Q("10 A"), 1.0, 0.8, 0.6, Q("48 V")).force.magnitude > 0
        True
        """
        r = hub.wheel_radius
        tau_wheel = (hub.torque_constant * current_limit).to(ureg.newton * ureg.meter)
        m_rot = (n_wheels * hub.rotating_mass_bound).to(ureg.kg)
        lim = calc_braking_limits(mass, deceleration, wheel_torque_max=tau_wheel, wheel_radius=r,
                                  n_driven_wheels=n_wheels, friction_coefficient=mu_dry,
                                  drive_load_share=drive_load_share, rotating_equivalent_mass=m_rot,
                                  cg_height=cg_height, tip_arm=tip_arm)
        a_rated = calc_drive_torque_deceleration_limit(hub.rated_torque, r, n_wheels, mass, m_rot)["a_max"]
        volts = calc_drive_voltage_headroom(hub.back_emf_constant, speed, r, bus_low, current_limit,
                                            hub.line_resistance)
        return BrakingCeilingsResult(
            wheel_torque=tau_wheel, force=lim["force"], rotating_mass=m_rot, rotating_share=_ratio(m_rot, mass),
            m_eff=lim["m_eff"], a_torque=lim["a_torque"], torque_margin=_ratio(lim["a_torque"], deceleration) - 1,
            a_torque_rated=a_rated, mu_required=calc_required_friction(deceleration),
            drive_load_share=drive_load_share, mu_required_rated=lim["mu_required"],
            min_load_share_dry=_ratio(deceleration, mu_dry * ureg.standard_gravity),
            a_traction_dry=lim["a_traction"], a_traction_inspected=calc_traction_deceleration_limit(mu_inspected),
            cg_ratio_max=lim["cg_ratio_max"], a_tip=lim["a_tip"], passes=lim["passes"],
            wheel_speed=volts["omega"], back_emf=volts["e_bemf"], v_brake=volts["v_brake"],
            v_drive=volts["v_drive"], headroom=volts["headroom"],
        )


class HubDriveElectricalModel(ForwardModel):
    """
    Electrical time constant, voltage-limited current ramp, and phase-short braking peak of a hub drive.

    tau_e = L / R (line quantities, the same ratio as per phase for a star
    winding); at stall the back-EMF is zero, so the full bus voltage ramps the
    current at V / L: t = L I / V. Shorted windings brake hardest where the
    winding reactance equals its resistance: omega_e = R / L, which is
    omega_e / p at the wheel for p pole pairs. The same R / L, divided by
    2 pi, is the winding's current pole in hertz.
    """
    requires = ()
    produces = HubDriveElectricalResult

    def solve(self, hub, current_limit: Quantity, bus_voltage: Quantity, brake_onset: Quantity) -> HubDriveElectricalResult:
        """Electrical time constant, voltage-limited current ramp, and phase-short braking peak of a hub drive.

        Parameters
        ----------
        hub : object
            Motor specification with line inductance/resistance, peak current, and pole pairs.
        current_limit : Quantity
            Positive target current (A).
        bus_voltage : Quantity
            Positive applied voltage (V).
        brake_onset : Quantity
            Positive allotted electrical onset time (s).

        Returns
        -------
        HubDriveElectricalResult
            Electrical times in ms, currents in A, electrical speed in rad/s, wheel speed in rpm, and pole frequency in Hz.

        Notes
        -----
        Equation: Electrical time constant is L/R; initial ramp time is ``L*current_limit/bus_voltage``. Full-step current is bus_voltage/R. The short-braking peak electrical speed is R/L, wheel speed is (R/L)/pole_pairs, and pole frequency is ``R/(2*pi*L)``.

        Assumptions: Linear winding inductance/resistance; zero back-EMF during current-ramp calculation.

        Excludes: PWM switching, magnetic saturation, and inverter dynamics.

        References
        ----------
        Derivation: The series RL circuit equation at zero back-EMF gives the initial current slope V/L and steady current V/R. The short-braking speed estimate equates winding reactance and resistance; it assumes the linear sinusoidal electrical model.

        Examples
        --------
        >>> from mlsysim.core.units import Q_ as Q
        >>> from types import SimpleNamespace
        >>> hub = SimpleNamespace(wheel_radius=Q("0.1 m"), torque_constant=Q("1 N*m/A"), rotating_mass_bound=Q("1 kg"), rated_torque=Q("1 N*m"), peak_torque=Q("2 N*m"), back_emf_constant=Q("1 V*s/rad"), line_resistance=Q("1 ohm"), line_inductance=Q("0.001 H"), peak_current=Q("20 A"), pole_pairs=10)
        >>> HubDriveElectricalModel().solve(hub, Q("10 A"), Q("48 V"), Q("0.01 s")).time_constant.magnitude > 0
        True
        """
        l_, r_ = hub.line_inductance, hub.line_resistance
        ramp = (l_ * current_limit / bus_voltage).to(_MS)
        full = (bus_voltage / r_).to(ureg.ampere)
        w_e = (r_ / l_).to(ureg.radian / ureg.second)
        return HubDriveElectricalResult(
            time_constant=(l_ / r_).to(_MS), ramp_time=ramp, ramp_share=_ratio(ramp, brake_onset),
            full_step_current=full, step_over_peak=_ratio(full, hub.peak_current),
            short_peak_electrical=w_e, short_peak_wheel_speed=(w_e / hub.pole_pairs).to(ureg.revolution / ureg.minute),
            pole_frequency=(r_ / (2 * math.pi * l_)).to(ureg.hertz),
        )


class GearedRotorModel(ForwardModel):
    """
    Reflected rotor inertia N^2 J_rotor, sized as a solid flywheel, and the inertia match.

    A solid disk of radius r has J = m r^2 / 2, so m = 2 J / r^2. Joint
    acceleration for a fixed motor torque peaks at N* = sqrt(J_load / J_rotor);
    at N it is 2x / (1 + x^2) of that peak, x = N / N*.
    """
    requires = ()
    produces = GearedRotorResult

    def solve(self, gear_ratio: float, rotor_mass: Quantity, rotor_inertia: Quantity,
              flywheel_radius: Quantity, load_inertia: Quantity) -> GearedRotorResult:
        """Reflected rotor inertia N^2 J_rotor, sized as a solid flywheel, and the inertia match.

        Parameters
        ----------
        gear_ratio : float
            Positive output reduction ratio.
        rotor_mass : Quantity
            Positive rotor mass (kg).
        rotor_inertia : Quantity
            Positive rotor inertia (kg*m^2).
        flywheel_radius : Quantity
            Positive equivalent solid-disk radius (m).
        load_inertia : Quantity
            Positive output load inertia (kg*m^2).

        Returns
        -------
        GearedRotorResult
            Reflected inertia in kg*m^2, equivalent mass in kg, radius in mm, and dimensionless response share.

        Notes
        -----
        Equation: Reflected inertia is ``gear_ratio^2*rotor_inertia``. Equivalent disk mass is ``2*reflected_inertia/flywheel_radius^2``. Matched ratio Nstar = sqrt(load_inertia/rotor_inertia); normalized acceleration is ``2*x/(1+x^2)``, x = gear_ratio/Nstar.

        Assumptions: Ideal rigid transmission and solid-disk equivalent flywheel.

        Excludes: Gear compliance, friction, and efficiency losses.

        References
        ----------
        Derivation: Conservation of rotational kinetic energy reflects inertia through the square of the speed ratio. The disk equivalent uses J = ``m*r^2/2``. Maximizing acceleration at fixed motor torque over reduction ratio gives the inertia match; see mlsysim.physics.motors.calc_inertia_matched_ratio.

        Examples
        --------
        >>> from mlsysim.core.units import Q_ as Q
        >>> GearedRotorModel().solve(10, Q("1 kg"), Q("0.01 kg*m^2"), Q("0.1 m"), Q("1 kg*m^2")).reflected_inertia.magnitude > 0
        True
        """
        j_ref = calc_reflected_inertia(gear_ratio, rotor_inertia).to(ureg.kg * ureg.meter ** 2)
        n_star = calc_inertia_matched_ratio(load_inertia, rotor_inertia)
        return GearedRotorResult(
            reflected_inertia=j_ref, flywheel_mass=(2 * j_ref / flywheel_radius ** 2).to(ureg.kg),
            radius_of_gyration=((rotor_inertia / rotor_mass) ** 0.5).to(_MM), matched_ratio=n_star,
            acceleration_share=calc_peak_normalized_response(gear_ratio / n_star),
        )


class GearRatioCostModel(ForwardModel):
    """
    Holding heat and reflected inertia of one motor holding one joint torque, per gear ratio.

    Motor torque tau_m = tau_out / (eta N); copper loss (tau_m / K_m)^2 with
    K_m = K_t / sqrt(R_loss); reflected inertia N^2 J_in. Their product is
    tau_out^2 J_in / (eta^2 K_m^2), independent of N.
    """
    requires = ()
    produces = GearRatioCostResult

    def solve(self, motor, loss_resistance: Quantity, input_inertia: Quantity, output_torque: Quantity,
              gear_efficiency: float, ratios: Iterable[int]) -> GearRatioCostResult:
        """Holding heat and reflected inertia of one motor holding one joint torque, per gear ratio.

        Parameters
        ----------
        motor : object
            Motor specification with torque constant, peak torque, and rated torque.
        loss_resistance : Quantity
            Positive equivalent copper-loss resistance (ohm).
        input_inertia : Quantity
            Positive input-side inertia (kg*m^2).
        output_torque : Quantity
            Required joint holding torque (N*m).
        gear_efficiency : float
            Transmission efficiency in (0, 1].
        ratios : Iterable[int]
            Iterable of positive integer reduction ratios.

        Returns
        -------
        GearRatioCostResult
            Per-ratio dictionaries of torque (N*m), copper loss (W), and reflected inertia (kg*m^2).

        Notes
        -----
        Equation: For reduction N, motor torque is ``output_torque/(gear_efficiency*N)``, motor constant Km = torque_constant/sqrt(loss_resistance), copper loss = (motor_torque/Km)^2, and reflected inertia = ``N^2*input_inertia``.

        Assumptions: Constant torque constant, loss resistance, and efficiency across ratios.

        Excludes: Motion losses, gear mass, and temperature feedback.

        References
        ----------
        Derivation: Combining torque = ``Kt*current`` with Joule loss ``current^2*R`` gives the torque-squared loss expression. Reflection increases inertia quadratically while required motor torque decreases inversely with reduction; their loss-inertia product therefore cancels N under fixed efficiency.

        Examples
        --------
        >>> from mlsysim.core.units import Q_ as Q
        >>> from types import SimpleNamespace
        >>> hub = SimpleNamespace(wheel_radius=Q("0.1 m"), torque_constant=Q("1 N*m/A"), rotating_mass_bound=Q("1 kg"), rated_torque=Q("1 N*m"), peak_torque=Q("2 N*m"), back_emf_constant=Q("1 V*s/rad"), line_resistance=Q("1 ohm"), line_inductance=Q("0.001 H"), peak_current=Q("20 A"), pole_pairs=10)
        >>> GearRatioCostModel().solve(hub, Q("1 ohm"), Q("0.01 kg*m^2"), Q("10 N*m"), 0.9, [10, 20]).copper_loss[10].magnitude > 0
        True
        """
        k_m = (motor.torque_constant / loss_resistance ** 0.5).to(ureg.newton * ureg.meter / ureg.watt ** 0.5)
        tm, loss, jr, prod, over = {}, {}, {}, {}, {}
        for n in ratios:
            tm[n] = (output_torque / (gear_efficiency * n)).to(ureg.newton * ureg.meter)
            loss[n] = ((tm[n] / k_m) ** 2).to(ureg.watt)
            jr[n] = (n ** 2 * input_inertia).to(ureg.kg * ureg.meter ** 2)
            prod[n] = (loss[n] * jr[n]).to(ureg.watt * ureg.kg * ureg.meter ** 2)
            over[n] = _ratio(tm[n], motor.peak_torque)
        return GearRatioCostResult(motor_constant=k_m, motor_torque=tm, copper_loss=loss, reflected_inertia=jr,
                                   loss_inertia_product=prod, over_peak=over,
                                   peak_over_rated=_ratio(motor.peak_torque, motor.rated_torque))


class ThermalBurstModel(ForwardModel):
    """
    Burst horizons from a cold and a heat-soaked start, the average-power duty screen, and the periodic peak.

    First-order lumped winding at fixed resistance: tau = theta C; the burst
    drives the winding toward T_amb + P theta; the duty screen holds the average
    loss to (T_ceiling - T_amb) / theta; the off-time is rounded up to 0.1 s and
    the resulting schedule's periodic peak is checked against the ceiling.
    """
    requires = ()
    produces = ThermalBurstResult

    def solve(self, rated_current: Quantity, loss_resistance: Quantity, thermal_capacitance: Quantity,
              thermal_resistance: Quantity, ambient: Quantity, limit: Quantity, ceiling: Quantity,
              burst_factor: float, burst_on: Quantity) -> ThermalBurstResult:
        """Burst horizons from a cold and a heat-soaked start, the average-power duty screen, and the periodic peak.

        Parameters
        ----------
        rated_current : Quantity
            Positive rated current (A).
        loss_resistance : Quantity
            Fixed copper-loss resistance (ohm).
        thermal_capacitance : Quantity
            Positive lumped winding heat capacity (J/K).
        thermal_resistance : Quantity
            Positive winding-to-ambient resistance (K/W).
        ambient : Quantity
            Absolute ambient temperature (K).
        limit : Quantity
            Absolute burst temperature limit (K).
        ceiling : Quantity
            Absolute average-operation temperature ceiling (K).
        burst_factor : float
            Positive multiplier on rated current.
        burst_on : Quantity
            Positive burst duration (s).

        Returns
        -------
        ThermalBurstResult
            Thermal horizons in s, temperatures in K, losses in W, burst current in A, and dimensionless duty.

        Notes
        -----
        Equation: Thermal time constant is ``thermal_resistance*thermal_capacitance``. Burst loss is ``(burst_factor*rated_current)^2*loss_resistance``; asymptotic temperature is ``ambient+burst_loss*thermal_resistance``. Duty = ``(ceiling-ambient)/(thermal_resistance*burst_loss)``; off-time is ``burst_on*(1-duty)/duty``, rounded upward to tenths of a second for the periodic check.

        Assumptions: Single thermal pole and fixed resistance; choose limits below the burst asymptote for finite heating horizons.

        Excludes: Temperature-dependent resistance, spatial hot spots, and thermal protection certification.

        References
        ----------
        Derivation: The lumped thermal energy balance gives exponential heating toward ``ambient+power*thermal_resistance``. Inverting this exponential yields cold and hot horizons. See mlsysim.physics.motors.calc_first_order_time_to_temperature and calc_periodic_burst_peak_rise; average-power screening alone does not bound the periodic peak.

        Examples
        --------
        >>> from mlsysim.core.units import Q_ as Q
        >>> ThermalBurstModel().solve(Q("1 A"), Q("1 ohm"), Q("10 J/K"), Q("1 K/W"), Q("300 K"), Q("303 K"), Q("302 K"), 2, Q("1 s")).burst_loss.magnitude > 0
        True
        """
        tau = (thermal_resistance * thermal_capacitance).to(ureg.second)
        amb = ambient.to(_K)
        p_rated = (rated_current ** 2 * loss_resistance).to(ureg.watt)
        t_eq = (amb + p_rated * thermal_resistance).to(_K)
        i_burst = (burst_factor * rated_current).to(ureg.ampere)
        p_burst = (i_burst ** 2 * loss_resistance).to(ureg.watt)
        t_inf = (amb + p_burst * thermal_resistance).to(_K)
        cold = calc_first_order_time_to_temperature(amb, limit, t_inf, tau)
        hot = calc_first_order_time_to_temperature(t_eq, limit, t_inf, tau)
        p_avg = ((ceiling.to(_K) - amb) / thermal_resistance).to(ureg.watt)
        duty = _ratio(p_avg, p_burst)
        off = (burst_on * (1 - duty) / duty).to(ureg.second)
        off_sched = math.ceil(off.magnitude * 10) / 10 * ureg.second   # screening value rounded up to 0.1 s
        peak = (amb + calc_periodic_burst_peak_rise(p_burst, thermal_resistance, burst_on, burst_on + off_sched, tau)).to(_K)
        return ThermalBurstResult(
            time_constant=tau, rated_loss=p_rated, rated_equilibrium=t_eq, burst_current=i_burst, burst_loss=p_burst,
            asymptote=t_inf, horizon_cold=cold, horizon_hot=hot, hot_cut=1 - _ratio(hot, cold),
            average_loss_max=p_avg, duty=duty, off_time=off, off_time_scheduled=off_sched, periodic_peak=peak,
        )


class StallDeratingModel(ForwardModel):
    """
    Steady stall temperature with copper's resistance feedback, and the hold the winding can sustain.

    Steady state: dT = I^2 R_0 [1 + alpha (T_amb - T_0 + dT)] theta, linear in
    dT, so dT = c / (1 - g) with loop gain g = I^2 R_0 theta alpha (runaway if
    g >= 1). The sustainable loss at the limit is (T_limit - T_amb) / theta at
    the hot resistance R(T_limit).
    """
    requires = ()
    produces = StallDeratingResult

    def solve(self, hold_torque: Quantity, gear_ratio: float, gear_efficiency: float, torque_constant: Quantity,
              loss_resistance: Quantity, thermal_resistance: Quantity, ambient: Quantity,
              limit: Quantity) -> StallDeratingResult:
        """Steady stall temperature with copper's resistance feedback, and the hold the winding can sustain.

        Parameters
        ----------
        hold_torque : Quantity
            Required output holding torque (N*m).
        gear_ratio : float
            Positive reduction ratio.
        gear_efficiency : float
            Transmission efficiency in (0, 1].
        torque_constant : Quantity
            Positive motor torque constant (N*m/A).
        loss_resistance : Quantity
            Positive resistance at the copper reference temperature (ohm).
        thermal_resistance : Quantity
            Positive winding-to-ambient resistance (K/W).
        ambient : Quantity
            Absolute ambient temperature (K).
        limit : Quantity
            Absolute winding limit above ambient (K).

        Returns
        -------
        StallDeratingResult
            Steady thermal rise in K, current in A, resistance in ohm, loss in W, and sustainable torque in N*m.

        Notes
        -----
        Equation: Motor current I = ``hold_torque/(gear_efficiency*gear_ratio*torque_constant)``. With copper coefficient alpha, cold resistance R0, and thermal resistance theta, feedback gain g = ``I^2*R0*theta*alpha``. Steady rise is ``I^2*R0*theta*(1+alpha*(ambient-T0))/(1-g)``. Sustainable current is ``sqrt((limit-ambient)/(theta*R(limit)))``.

        Assumptions: Linear copper resistance feedback; finite stable equilibrium requires feedback_gain < 1.

        Excludes: Nonlinear heat transfer and runaway transient dynamics; algebraic output above unit gain is not a stable equilibrium.

        References
        ----------
        Derivation: Substitute the linear copper resistance-temperature relation into steady Joule heating and collect terms in temperature rise. The resulting denominator exposes the unit-gain instability. See mlsysim.physics.motors.calc_copper_resistance_factor for the reference-temperature convention.

        Examples
        --------
        >>> from mlsysim.core.units import Q_ as Q
        >>> StallDeratingModel().solve(Q("1 N*m"), 10, 0.9, Q("1 N*m/A"), Q("1 ohm"), Q("1 K/W"), Q("300 K"), Q("350 K")).sustainable_current.magnitude > 0
        True
        """
        alpha, t0 = COPPER_TEMPERATURE_COEFFICIENT, COPPER_COEFFICIENT_REFERENCE_TEMPERATURE
        tau_m = (hold_torque / (gear_efficiency * gear_ratio)).to(ureg.newton * ureg.meter)
        i = (tau_m / torque_constant).to(ureg.ampere)
        p_cold = (i ** 2 * loss_resistance).to(ureg.watt)
        base = (i ** 2 * loss_resistance * thermal_resistance).to(_K)
        const = (base * calc_copper_resistance_factor(ambient, alpha, t0)).to(_K)
        gain = float((base * alpha).to("").magnitude)
        rise = (const / (1 - gain)).to(_K)
        p_max = ((limit.to(_K) - ambient.to(_K)) / thermal_resistance).to(ureg.watt)
        r_hot = (loss_resistance * calc_copper_resistance_factor(limit, alpha, t0)).to(ureg.ohm)
        i_max = ((p_max / r_hot) ** 0.5).to(ureg.ampere)
        hold = (gear_efficiency * gear_ratio * torque_constant * i_max).to(ureg.newton * ureg.meter)
        return StallDeratingResult(
            motor_torque=tau_m, stall_current=i, cold_loss=p_cold, feedback_constant=const, feedback_gain=gain,
            steady_rise=rise, winding_temperature=(ambient.to(_K) + rise).to(_K), sustainable_loss=p_max,
            hot_resistance=r_hot, sustainable_current=i_max, sustainable_hold=hold, derating=1 - _ratio(hold, hold_torque),
        )


class ContinuousDeratingModel(ForwardModel):
    """
    Installed continuous torque relative to the catalog rating.

    Continuous torque scales as sqrt((T_max - T_amb) / theta): a hotter
    ambient and a larger installed thermal resistance each cut it.
    """
    requires = ()
    produces = ContinuousDeratingResult

    def solve(self, ceiling: Quantity, catalog_ambient: Quantity, installed_ambient: Quantity,
              thermal_resistance_factor: float) -> ContinuousDeratingResult:
        """Installed continuous torque relative to the catalog rating.

        Parameters
        ----------
        ceiling : Quantity
            Absolute winding temperature ceiling (K).
        catalog_ambient : Quantity
            Catalog ambient below ceiling (K).
        installed_ambient : Quantity
            Installed ambient below ceiling (K).
        thermal_resistance_factor : float
            Positive installed/catalog thermal resistance ratio.

        Returns
        -------
        ContinuousDeratingResult
            Dimensionless installed/catalog torque shares for ambient alone and combined thermal effects.

        Notes
        -----
        Equation: Ambient-only torque share is sqrt((ceiling-installed_ambient)/(ceiling-catalog_ambient)); combined share divides this by sqrt(thermal_resistance_factor).

        Assumptions: Torque proportional to current and copper loss proportional to current squared.

        Excludes: Temperature-dependent electrical resistance and transient bursts.

        References
        ----------
        Derivation: At equilibrium, allowable copper power is temperature headroom divided by thermal resistance. Fixed resistance makes allowable current proportional to the square root of this power, and fixed torque constant makes torque proportional to current.

        Examples
        --------
        >>> from mlsysim.core.units import Q_ as Q
        >>> ContinuousDeratingModel().solve(Q("350 K"), Q("300 K"), Q("320 K"), 2).combined_share < 1
        True
        """
        amb = _ratio(ceiling.to(_K) - installed_ambient.to(_K), ceiling.to(_K) - catalog_ambient.to(_K)) ** 0.5
        return ContinuousDeratingResult(ambient_share=amb, combined_share=amb / thermal_resistance_factor ** 0.5)


class DriveBusModel(ForwardModel):
    """
    A shared drive bus: sustained sag under a coincident load step, and the regenerative surge of a stop.

    Sag Delta V = Delta I R_bus against the converter lockout; the step current
    that would spend the depleted pack's headroom is (V_low - V_uvlo) / R_bus.
    A stop from speed v returns a share of (1/2) m v^2; into the bus capacitance
    alone, V_final = sqrt(V_full^2 + 2 E / C). Speed falls linearly at constant
    deceleration, so regenerated power falls linearly from 2 E / t_stop, and a
    chopper resistor at the clamp must satisfy R <= V_clamp^2 / P_peak.
    """
    requires = ()
    produces = DriveBusResult

    def solve(self, mass: Quantity, speed: Quantity, deceleration: Quantity, step_current: Quantity,
              bus_resistance: Quantity, full: Quantity, nominal: Quantity, depleted: Quantity, lockout: Quantity,
              compute_power: Quantity, converter_efficiency: float, capacitance: Quantity, clamp: Quantity,
              regen_fraction: float) -> DriveBusResult:
        """A shared drive bus: sustained sag under a coincident load step, and the regenerative surge of a stop.

        Parameters
        ----------
        mass : Quantity
            Positive moving mass (kg).
        speed : Quantity
            Positive entry speed (m/s).
        deceleration : Quantity
            Positive constant deceleration (m/s^2).
        step_current : Quantity
            Positive coincident current increase (A).
        bus_resistance : Quantity
            Positive supply-path resistance (ohm).
        full : Quantity
            Full-pack voltage (V).
        nominal : Quantity
            Nominal voltage (V).
        depleted : Quantity
            Depleted-pack voltage (V).
        lockout : Quantity
            Converter undervoltage lockout (V).
        compute_power : Quantity
            Compute load power (W).
        converter_efficiency : float
            Converter efficiency in (0, 1].
        capacitance : Quantity
            Positive bus capacitance (F).
        clamp : Quantity
            Regeneration clamp voltage (V).
        regen_fraction : float
            Fraction of kinetic energy recovered, in (0, 1].

        Returns
        -------
        DriveBusResult
            Bus voltages in V, currents in A, energies in J, stop time in ms, peak power in W, and resistor bound in ohm.

        Notes
        -----
        Equation: Compute current = ``compute_power/(converter_efficiency*nominal)``; sag = ``step_current*bus_resistance``. Recovered energy E = ``regen_fraction*mass*speed^2/2`` gives capacitor-only endpoint ``sqrt(full^2+2*E/capacitance)``. Stop duration = speed/deceleration, peak regenerative power = ``2*E/stop_duration``, and resistor ceiling = clamp^2/peak_power.

        Assumptions: Constant deceleration, resistive sustained sag, and stated energy-recovery fraction.

        Excludes: Inductive transients, battery absorption, and chopper switching dynamics.

        References
        ----------
        Derivation: Ohm's law gives sustained sag. Equating recovered kinetic energy to the increase in capacitor energy gives the endpoint voltage. Constant deceleration makes recovery power triangular in time, so its peak is twice its mean. This treats the capacitor-only case separately from battery absorption.

        Examples
        --------
        >>> from mlsysim.core.units import Q_ as Q
        >>> DriveBusModel().solve(Q("100 kg"), Q("1 m/s"), Q("1 m/s^2"), Q("10 A"), Q("0.1 ohm"), Q("48 V"), Q("44 V"), Q("40 V"), Q("36 V"), Q("100 W"), 0.9, Q("1 F"), Q("50 V"), 0.5).regenerated.magnitude > 0
        True
        """
        i_compute = (compute_power / (converter_efficiency * nominal)).to(ureg.ampere)
        sag = calc_voltage_droop(step_current, bus_resistance).to(ureg.volt)
        e_k = calc_kinetic_energy(mass, speed).to(ureg.joule)
        e_regen = (regen_fraction * e_k).to(ureg.joule)
        t_stop = (speed / deceleration).to(_MS)
        p_peak = (2 * e_regen / t_stop).to(ureg.watt)
        return DriveBusResult(
            compute_current=i_compute, drive_current=(step_current - i_compute).to(ureg.ampere), sag=sag,
            sustained_full=(full - sag).to(ureg.volt), sustained_depleted=(depleted - sag).to(ureg.volt),
            margin_depleted=(depleted - sag - lockout).to(ureg.volt), headroom_depleted=(depleted - lockout).to(ureg.volt),
            crossing_current=((depleted - lockout) / bus_resistance).to(ureg.ampere),
            kinetic_energy=e_k, regenerated=e_regen,
            capacitor_only_endpoint=((full ** 2 + 2 * e_regen / capacitance) ** 0.5).to(ureg.volt),
            capacitor_to_clamp=(0.5 * capacitance * (clamp ** 2 - full ** 2)).to(ureg.joule),
            stop_time=t_stop, peak_power=p_peak, resistor_max=(clamp ** 2 / p_peak).to(ureg.ohm),
            crossing_resistance=((depleted - lockout) / step_current).to(ureg.ohm),
        )


class ZeroFailureModel(ForwardModel):
    """
    Upper bound on the per-trial failure rate after a failure-free campaign.

        Poisson (rule of three):  p_upper = -ln(1 - C) / n
        exact binomial:           p_upper = 1 - (1 - C)^(1/n)

    With ``target_rate``, also the clean trials that bound the rate at the
    target: ceil(ln(1 - C) / ln(1 - target)), and its rule-of-three estimate
    -ln(1 - C) / target (exact form and target added 2026-10-20).
    """
    requires = ()
    produces = ZeroFailureResult

    def solve(self, trials: int, confidence: float,
              target_rate: Optional[float] = None) -> ZeroFailureResult:
        """Upper bound on the per-trial failure rate after a failure-free campaign.

        Parameters
        ----------
        trials : int
            Positive number of independent failure-free trials.
        confidence : float
            One-sided confidence level in (0, 1).
        target_rate : Optional[float]
            Optional target per-trial failure probability in (0, 1).

        Returns
        -------
        ZeroFailureResult
            Dimensionless approximate/exact failure bounds and trial counts; optional target counts are None when no target is supplied.

        Notes
        -----
        Equation: For n trials and confidence C, approximate upper failure probability is -ln(1-C)/n; exact upper probability is 1-(1-C)^(1/n). A target p requires ceil(ln(1-C)/ln(1-p)) failure-free trials.

        Assumptions: Independent identically distributed Bernoulli trials; approximate rate uses the zero-event Poisson bound.

        Excludes: Nonstationarity, correlated failures, and proof of absence of failures.

        References
        ----------
        Derivation: For independent Bernoulli trials, the probability of zero failures is (1-p)^n. Invert this probability at tail mass 1-C to obtain the exact one-sided bound. Replacing ln(1-p) by -p yields the Poisson approximation; see mlsysim.physics.robotics.assurance.calc_zero_failure_sample_size.

        Examples
        --------
        >>> from mlsysim.core.units import Q_ as Q
        >>> ZeroFailureModel().solve(100, 0.95).rate_upper_exact < 1
        True
        """
        p = calc_zero_failure_rate_upper_bound(trials, confidence)
        coefficient = -math.log(1 - confidence)
        needed = needed_approx = None
        if target_rate is not None:
            needed = calc_zero_failure_sample_size(1 - target_rate, confidence)
            needed_approx = coefficient / target_rate
        return ZeroFailureResult(
            coefficient=coefficient, rate_upper=p, one_in=1 / p,
            rate_upper_exact=1 - calc_clopper_pearson_zero_failure_bound(trials, confidence),
            trials_for_target=needed, trials_for_target_approx=needed_approx,
        )


class ExponentialRareEventModel(ForwardModel):
    """
    One rare exponential tail estimated by plain Monte Carlo, a zero-failure
    campaign, and cross-entropy importance sampling (added 2026-10-20).

    The operational variable is exponential with ``mean``; failure is a draw
    past ``threshold``, so p = exp(-threshold / mean). Plain Monte Carlo needs
    (1 - p) / (p r^2) runs for relative error r; a zero-failure campaign needs
    ceil(ln(1 - C) / ln(1 - p)) clean runs to bound p. The cross-entropy method
    with ``elite_share`` reaches the threshold in a few levels; its exponential
    proposal gives the per-draw relative variance, the weighted runs for r,
    the share of proposal draws that fail, and the effective sample size.
    """
    requires = ()
    produces = ExponentialRareEventResult

    def solve(self, threshold: Quantity, mean: Quantity, elite_share: float, relative_error: float,
              confidence: float) -> ExponentialRareEventResult:
        """One rare exponential tail estimated by plain Monte Carlo, a zero-failure campaign, and cross-entropy importance sampling (added 2026-10-20).

        Parameters
        ----------
        threshold : Quantity
            Positive failure threshold, in the same units as mean.
        mean : Quantity
            Positive operational exponential mean.
        elite_share : float
            Cross-entropy elite fraction in (0, 1).
        relative_error : float
            Positive target relative standard error.
        confidence : float
            One-sided confidence level in (0, 1).

        Returns
        -------
        ExponentialRareEventResult
            Analytic failure probabilities, dimensionless variances, effective counts, and proposal mean in the input units.

        Notes
        -----
        Equation: Failure probability p = exp(-threshold/mean). Plain Monte Carlo requires ``(1-p)/(p*relative_error^2)`` draws; importance sampling requires relative_variance/relative_error^2. Proposal means and variances come from the analytic exponential cross-entropy and importance-sampling helpers.

        Assumptions: Exponential operational and proposal families with analytic importance weights.

        Excludes: Empirical sampling, distribution misspecification, and device measurements.

        References
        ----------
        Derivation: The exponential survival function gives p. Bernoulli variance divided by squared target absolute error gives the ordinary sample budget. Applying the same variance-to-error calculation to likelihood-weighted draws yields the importance budget; see mlsysim.physics.statistics.calc_importance_sampling_exponential and calc_cross_entropy_exponential_proposal.

        Examples
        --------
        >>> from mlsysim.core.units import Q_ as Q
        >>> ExponentialRareEventModel().solve(Q("5 s"), Q("1 s"), 0.1, 0.1, 0.95).failure_probability < 1
        True
        """
        ce = calc_cross_entropy_exponential_proposal(threshold, mean, elite_share)
        weighted = calc_importance_sampling_exponential(threshold, mean, ce["proposal_mean"])
        p = weighted["failure_probability"]
        n_mc = calc_monte_carlo_sample_size(p, relative_error)
        n_is = weighted["relative_variance"] / relative_error ** 2
        m_opt = calc_optimal_exponential_proposal_mean(threshold, mean)
        best = calc_importance_sampling_exponential(threshold, mean, m_opt)["relative_variance"]
        return ExponentialRareEventResult(
            threshold=threshold, failure_probability=p, monte_carlo_runs=n_mc,
            zero_failure_runs=calc_zero_failure_sample_size(1.0 - p, confidence),
            levels=ce["levels"], n_levels=ce["n_levels"], proposal_mean=ce["proposal_mean"],
            proposal_failure_share=weighted["proposal_failure_share"],
            relative_variance=weighted["relative_variance"], importance_runs=n_is,
            ess_per_draw=weighted["ess_per_draw"], effective_sample_size=n_is * weighted["ess_per_draw"],
            optimal_proposal_mean=m_opt, proposal_penalty=weighted["relative_variance"] / best - 1.0,
            speedup=n_mc / n_is,
        )


class DiagnosticCoverageModel(ForwardModel):
    """
    Diagnostic coverage that leaves at most ``target`` of a raw fault rate
    unmitigated, and the zero-miss injection campaign that demonstrates it
    (added 2026-10-20).

    Rates are in FIT (faults per 10^9 hours). The raw rate is the sum of the
    strata; coverage C_diag = 1 - target / raw. Each injection misses with
    probability 1 - C_diag, so n zero-miss injections bound it at confidence
    C when n >= ln(1 - C) / ln(C_diag); the rule of three approximates n by
    3 / (1 - C_diag). Drawn in proportion to the rates, each stratum receives
    its share of the n injections.
    """
    requires = ()
    produces = DiagnosticCoverageResult

    def solve(self, strata: Dict[str, float], target: float, confidence: float) -> DiagnosticCoverageResult:
        """Diagnostic coverage that leaves at most ``target`` of a raw fault rate unmitigated, and the zero-miss injection campaign that demonstrates it (added 2026-10-20).

        Parameters
        ----------
        strata : Dict[str, float]
            Mapping from stratum names to nonnegative fault rates (FIT), positive total.
        target : float
            Positive residual rate below the total, in FIT.
        confidence : float
            One-sided confidence level in (0, 1).

        Returns
        -------
        DiagnosticCoverageResult
            Fault-rate total in FIT, dimensionless coverage and shares, and injection counts.

        Notes
        -----
        Equation: Raw rate is sum(strata.values()); required coverage = 1-target/raw_rate. The exact real-valued trial threshold is ln(1-confidence)/ln(coverage), rounded upward for injections. Stratum share = stratum_rate/raw_rate; allocation = ``injections*share``.

        Assumptions: Independent representative injection trials and proportional stratum allocation.

        Excludes: Unequal detection probability by stratum, common-cause dependencies, and certification.

        References
        ----------
        Derivation: Residual faults are the raw rate times the missed fraction. For independent representative injections, observing no misses has probability coverage^n. Inverting that probability gives the trial threshold. Proportional allocations are expected counts, not a rounded stratified test design.

        Examples
        --------
        >>> from mlsysim.core.units import Q_ as Q
        >>> DiagnosticCoverageModel().solve({"sensor": 100.0}, 1.0, 0.95).injections > 0
        True
        """
        raw = sum(strata.values())
        coverage = 1.0 - target / raw
        n = calc_zero_failure_sample_size(coverage, confidence=confidence)
        shares = {k: v / raw for k, v in strata.items()}
        return DiagnosticCoverageResult(
            raw_rate=raw, coverage=coverage,
            injections_exact=math.log(1.0 - confidence) / math.log(coverage), injections=n,
            rule_of_three=3.0 / (1.0 - coverage),  # the rule of three's coefficient (Hanley and Lippman-Hand 1983)
            shares=shares, allocation={k: n * f for k, f in shares.items()},
        )


class ThrottledStageModel(ForwardModel):
    """A compute-bound stage at a fraction of full clock: its time scales by the inverse clock ratio,
    and the added age is paid as travel at the stated speed."""
    requires = ()
    produces = ThrottledStageResult

    def solve(self, stage_time: Quantity, clock_ratio: float, speed: Quantity) -> ThrottledStageResult:
        """A compute-bound stage at a fraction of full clock: its time scales by the inverse clock ratio, and the added age is paid as travel at the stated speed.

        Parameters
        ----------
        stage_time : Quantity
            Positive stage latency at full clock (s).
        clock_ratio : float
            Positive throttled/full clock ratio.
        speed : Quantity
            Motion speed during execution (m/s).

        Returns
        -------
        ThrottledStageResult
            Throttled time and added age in ms, and added travel in mm.

        Notes
        -----
        Equation: Throttled duration = stage_time/clock_ratio; added age = throttled duration-stage_time; added travel = ``speed*added`` age.

        Assumptions: Entire stage is compute bound and scales inversely with clock.

        Excludes: Memory stalls, DVFS transition time, and nonlinear frequency effects.

        References
        ----------
        Derivation: Fixed instruction work takes inversely proportional time as clock frequency changes when every relevant cycle scales with that clock. Constant-speed kinematics then converts the additional time into distance.

        Examples
        --------
        >>> from mlsysim.core.units import Q_ as Q
        >>> ThrottledStageModel().solve(Q("1 ms"), 0.5, Q("1 m/s")).added_age.magnitude > 0
        True
        """
        slow = (stage_time / clock_ratio).to(_MS)
        added = (slow - stage_time).to(_MS)
        return ThrottledStageResult(throttled=slow, added_age=added, added_travel=(speed * added).to(_MM))
