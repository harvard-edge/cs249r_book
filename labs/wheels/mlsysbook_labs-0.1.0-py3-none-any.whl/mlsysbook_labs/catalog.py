"""Versioned catalog for the MLSysBook interactive labs."""

from __future__ import annotations

from .schemas import LabMetadata


UPDATED_AT = "2026-10-20"


LAB_CATALOG: dict[str, LabMetadata] = {
    "vol1/lab_00_introduction.py": LabMetadata(
        lab_id="v1_00_architects_portal",
        title="Choose a Context",
        volume="Volume I",
        chapter="Orientation",
        book_anchor="Volume I orientation",
        lab_version="2.0.0",
        updated_at="2026-10-20",
    ),
    "vol1/lab_01_ml_intro.py": LabMetadata(
        lab_id="v1_01_ai_triad",
        title="Evidence Before Optimization",
        volume="Volume I",
        chapter="Chapter 1",
        book_anchor="Volume I, Chapter 1: Introduction to Machine Learning Systems",
        lab_version="2.0.0",
        updated_at="2026-10-20",
    ),
    "vol1/lab_02_system_paradigms.py": LabMetadata(
        lab_id="v1_02_physics_of_deployment",
        title="Where Should Inference Run?",
        volume="Volume I",
        chapter="Chapter 2",
        book_anchor="Volume I, Chapter 2: System Paradigms",
        lab_version="2.0.0",
        updated_at="2026-10-20",
    ),
    "vol1/lab_03_ml_lifecycle.py": LabMetadata(
        lab_id="v1_03_constraint_tax",
        title="Carry the Constraint",
        volume="Volume I",
        chapter="Chapter 3",
        book_anchor="Volume I, Chapter 3: ML Lifecycle",
        updated_at="2026-09-15",
    ),
    "vol1/lab_04_data_engr.py": LabMetadata(
        lab_id="v1_04_data_gravity",
        title="Evidence Through the Data Pipeline",
        volume="Volume I",
        chapter="Chapter 4",
        book_anchor="Volume I, Chapter 4: Data Engineering",
        updated_at="2026-09-15",
    ),
    "vol1/lab_05_nn_compute.py": LabMetadata(
        lab_id="v1_05_neural_computation",
        title="Tensor Costs",
        volume="Volume I",
        chapter="Chapter 5",
        book_anchor="Volume I, Chapter 5: Neural Computation",
        updated_at="2026-09-15",
    ),
    "vol1/lab_06_nn_arch.py": LabMetadata(
        lab_id="v1_06_architecture_tax",
        title="Architecture Commitments",
        volume="Volume I",
        chapter="Chapter 6",
        book_anchor="Volume I, Chapter 6: Neural Network Architectures",
        updated_at="2026-09-15",
    ),
    "vol1/lab_07_ml_frameworks.py": LabMetadata(
        lab_id="v1_07_framework_tax",
        title="The Framework Tax",
        volume="Volume I",
        chapter="Chapter 7",
        book_anchor="Volume I, Chapter 7: ML Frameworks",
        updated_at="2026-09-15",
    ),
    "vol1/lab_08_model_train.py": LabMetadata(
        lab_id="v1_08_training_gauntlet",
        title="Train for the Target, Not the Counter",
        volume="Volume I",
        chapter="Chapter 8",
        book_anchor="Volume I, Chapter 8: Model Training",
        updated_at="2026-09-15",
    ),
    "vol1/lab_09_data_selection.py": LabMetadata(
        lab_id="v1_09_selection_paradox",
        title="Selection That Pays",
        volume="Volume I",
        chapter="Chapter 9",
        book_anchor="Volume I, Chapter 9: Data Selection",
        updated_at="2026-09-15",
    ),
    "vol1/lab_10_model_compress.py": LabMetadata(
        lab_id="v1_10_compression_paradox",
        title="Compression That Executes",
        volume="Volume I",
        chapter="Chapter 10",
        book_anchor="Volume I, Chapter 10: Model Compression",
        updated_at="2026-09-15",
    ),
    "vol1/lab_11_hw_accel.py": LabMetadata(
        lab_id="v1_11_hardware_roofline",
        title="Acceleration That Survives the Whole Path",
        volume="Volume I",
        chapter="Chapter 11",
        book_anchor="Volume I, Chapter 11: Hardware Acceleration",
        updated_at="2026-09-15",
    ),
    "vol1/lab_12_perf_bench.py": LabMetadata(
        lab_id="v1_12_benchmarking_trap",
        title="Benchmark Claims That Survive",
        volume="Volume I",
        chapter="Chapter 12",
        book_anchor="Volume I, Chapter 12: Performance Benchmarking",
        updated_at="2026-09-15",
    ),
    "vol1/lab_13_model_serving.py": LabMetadata(
        lab_id="v1_13_tail_latency_trap",
        title="Serving Under Deadlines",
        volume="Volume I",
        chapter="Chapter 13",
        book_anchor="Volume I, Chapter 13: Model Serving",
        updated_at="2026-09-15",
    ),
    "vol1/lab_14_ml_ops.py": LabMetadata(
        lab_id="v1_14_silent_degradation",
        title="Evidence-Driven Operations",
        volume="Volume I",
        chapter="Chapter 14",
        book_anchor="Volume I, Chapter 14: ML Operations",
        updated_at="2026-09-15",
    ),
    "vol1/lab_15_responsible_engr.py": LabMetadata(
        lab_id="v1_15_no_free_fairness",
        title="Responsibility Is a System Requirement",
        volume="Volume I",
        chapter="Chapter 15",
        book_anchor="Volume I, Chapter 15: Responsible Engineering",
        updated_at="2026-09-15",
    ),
    "vol1/lab_16_ml_conclusion.py": LabMetadata(
        lab_id="v1_16_architects_audit",
        title="The Architect's Audit",
        volume="Volume I",
        chapter="Chapter 16",
        book_anchor="Volume I, Chapter 16: Conclusion",
        updated_at="2026-09-15",
    ),
    "vol2/lab_01_introduction.py": LabMetadata(
        lab_id="v2_01_scale_illusion",
        title="The Fleet Is the System",
        volume="Volume II",
        chapter="Chapter 1",
        book_anchor="Volume II, Chapter 1: Introduction",
        updated_at="2026-09-15",
    ),
    "vol2/lab_02_compute_infra.py": LabMetadata(
        lab_id="v2_02_compute_wall",
        title="The Compute Infrastructure Wall",
        volume="Volume II",
        chapter="Chapter 2",
        book_anchor="Volume II, Chapter 2: Compute Infrastructure",
        updated_at="2026-09-15",
    ),
    "vol2/lab_03_communication.py": LabMetadata(
        lab_id="v2_03_network_fabric_design",
        title="When Does the Fabric Become the Computer?",
        volume="Volume II",
        chapter="Chapter 3",
        book_anchor="Volume II, Chapter 3: Network Fabrics",
        updated_at="2026-09-15",
    ),
    "vol2/lab_04_data_storage.py": LabMetadata(
        lab_id="v2_04_data_pipeline_wall",
        title="The Data Pipeline Wall",
        volume="Volume II",
        chapter="Chapter 4",
        book_anchor="Volume II, Chapter 4: Data Storage",
        updated_at="2026-09-15",
    ),
    "vol2/lab_05_collective_communication.py": LabMetadata(
        lab_id="v2_05_collective_communication",
        title="Collective Communication",
        volume="Volume II",
        chapter="Chapter 5",
        book_anchor="Volume II, Chapter 5: Collective Communication",
        updated_at="2026-09-15",
        release_channel="preview",
    ),
    "vol2/lab_06_dist_train.py": LabMetadata(
        lab_id="v2_06_parallelism_design",
        title="Scaling Without Illusions",
        volume="Volume II",
        chapter="Chapter 6",
        book_anchor="Volume II, Chapter 6: Distributed Training",
        updated_at="2026-09-15",
    ),
    "vol2/lab_07_fault_tolerance.py": LabMetadata(
        lab_id="v2_07_failure_budget_engineering",
        title="When Failure Is Routine",
        volume="Volume II",
        chapter="Chapter 7",
        book_anchor="Volume II, Chapter 7: Fault Tolerance and Reliability",
        updated_at="2026-09-15",
    ),
    "vol2/lab_08_fleet_orch.py": LabMetadata(
        lab_id="v2_08_fleet_orchestration",
        title="Useful Work from a Shared Fleet",
        volume="Volume II",
        chapter="Chapter 8",
        book_anchor="Volume II, Chapter 8: Fleet Orchestration",
        updated_at="2026-09-15",
    ),
    "vol2/lab_09_perf_engineering.py": LabMetadata(
        lab_id="v2_09_optimization_trap",
        title="Optimize the Path",
        volume="Volume II",
        chapter="Chapter 9",
        book_anchor="Volume II, Chapter 9: Performance Engineering",
        updated_at="2026-09-15",
    ),
    "vol2/lab_10_inference.py": LabMetadata(
        lab_id="v2_10_inference_economy",
        title="The Inference Economy",
        volume="Volume II",
        chapter="Chapter 10",
        book_anchor="Volume II, Chapter 10: Inference at Scale",
        updated_at="2026-09-15",
    ),
    "vol2/lab_11_edge_intelligence.py": LabMetadata(
        lab_id="v2_11_edge_thermodynamics",
        title="Adaptation Across a Fleet",
        volume="Volume II",
        chapter="Chapter 11",
        book_anchor="Volume II, Chapter 11: Edge Intelligence",
        updated_at="2026-09-15",
    ),
    "vol2/lab_12_ops_scale.py": LabMetadata(
        lab_id="v2_12_silent_fleet",
        title="Operating a Shared ML Fleet",
        volume="Volume II",
        chapter="Chapter 12",
        book_anchor="Volume II, Chapter 12: ML Operations at Scale",
        updated_at="2026-09-15",
    ),
    "vol2/lab_13_security_privacy.py": LabMetadata(
        lab_id="v2_13_price_of_privacy",
        title="The Price of Privacy",
        volume="Volume II",
        chapter="Chapter 13",
        book_anchor="Volume II, Chapter 13: Security and Privacy",
        updated_at="2026-09-15",
    ),
    "vol2/lab_14_robust_ai.py": LabMetadata(
        lab_id="v2_14_robustness_budget",
        title="Evidence Under Shift",
        volume="Volume II",
        chapter="Chapter 14",
        book_anchor="Volume II, Chapter 14: Robust AI",
        updated_at="2026-09-15",
    ),
    "vol2/lab_15_sustainable_ai.py": LabMetadata(
        lab_id="v2_15_carbon_budget",
        title="Sustainable Fleet Decisions",
        volume="Volume II",
        chapter="Chapter 15",
        book_anchor="Volume II, Chapter 15: Sustainable AI",
        updated_at="2026-09-15",
    ),
    "vol2/lab_16_responsible_ai.py": LabMetadata(
        lab_id="v2_16_fairness_budget",
        title="Evidence for Responsible Release",
        volume="Volume II",
        chapter="Chapter 16",
        book_anchor="Volume II, Chapter 16: Responsible AI",
        updated_at="2026-09-15",
    ),
    "vol2/lab_17_fleet_synthesis.py": LabMetadata(
        lab_id="v2_17_fleet_synthesis",
        title="Fleet Synthesis",
        volume="Volume II",
        chapter="Chapter 17",
        book_anchor="Volume II, Chapter 17: Conclusion",
        updated_at="2026-09-15",
    ),
}


def _register_learning_paths() -> None:
    """Use generated chapter contracts as the canonical title/path catalog.

    Preserve established IDs referenced by captured reports. New volumes obtain
    deterministic identities without a second hand-maintained list.
    """
    from dataclasses import replace
    from importlib import resources
    import json

    directory = resources.files("mlsysbook_labs").joinpath("data", "learning_paths")
    if not directory.is_dir():
        return
    roman = {1: "I", 2: "II", 3: "III", 4: "IV"}
    for source in directory.iterdir():
        if not source.name.endswith(".json"):
            continue
        data = json.loads(source.read_text(encoding="utf-8"))
        number = int(data["volume"])
        for entry in data["chapters"]:
            path = entry["notebook"].removeprefix("labs/")
            if path in LAB_CATALOG:
                LAB_CATALOG[path] = replace(LAB_CATALOG[path], title=entry["title"])
            else:
                chapter = entry["chapter"]
                LAB_CATALOG[path] = LabMetadata(
                    lab_id=f"v{number}_{chapter:02d}", title=entry["title"],
                    volume=f"Volume {roman[number]}",
                    chapter="Orientation" if chapter == 0 else f"Chapter {chapter}",
                    book_anchor=entry.get("chapter_source") or "Volume orientation",
                    updated_at=UPDATED_AT,
                )


_register_learning_paths()


def get_lab_metadata(path: str) -> LabMetadata:
    """Resolve a canonical relative notebook path or an absolute source path."""
    normalized = str(path).replace("\\", "/")
    if normalized not in LAB_CATALOG:
        normalized = "/".join(normalized.split("/")[-2:])
    return LAB_CATALOG[normalized]
